import { StatusBar } from 'expo-status-bar';
import React, { useState, Component, useEffect, version, useMemo } from 'react';
import { StyleSheet, Text, View, Image, BackHandler, TouchableOpacity, TouchableHighlight, ImageBackground, TouchableWithoutFeedback, Modal } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { Button, Provider as PaperProvider, Title } from 'react-native-paper';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createStackNavigator } from '@react-navigation/stack';
import { ScrollView, PanGestureHandler } from 'react-native-gesture-handler';
import Dialog from "react-native-dialog";
import CountDown from 'react-native-countdown-component';


//import { render } from 'react-dom';
import Animated, { Easing, useSharedValue, useDerivedValue, interpolateColors, withSpring, useAnimatedStyle, repeat, delay, useAnimatedGestureHandler, withTiming, sequence, EasingNode, cancelAnimation, debug } from 'react-native-reanimated';


import * as Random from 'expo-random'; //랜덤값


const MORE_ICON = Platform.OS === 'ios' ? 'dots-horizontal' : 'dots-vertical';

const Stack = createStackNavigator();




const Box = (props) => {
  console.log('Box', props);
  const x = useSharedValue(0);
  const y = useSharedValue(0);
  const color = useSharedValue("blue");
  const scale = useSharedValue(1);
  const [active, setActive] = useState(false);
  const [changeGir, setChangeGir] = useState(require('./assets/giraffe.png'));

  useEffect(() => {
    activate(props.active);
  }, [props.active]);

  useEffect(() => {
    switch (props.action) {
      case "jump":
        jump();
        setTimeout(() => {
          props.cleanupAction();
        }, 200);
        break;
    }
  }, [props.action]);

  const aaaaaa = () => {
    scale.value = repeat(withTiming(scale.value + 0.1, { duration: 200, ease: Easing.linear }), -1, true);
    //y.value = repeat(withTiming(y.value - 80, { duration: 100 }), 2, true);
  }
  const bbbbbb = () => {
    scale.value = repeat(withTiming(scale.value - 0.3, { duration: 200, ease: Easing.linear }), 2, true);
    //y.value = repeat(withTiming(y.value - 80, { duration: 100 }), 2, true);
  }

  const setColor = (c) => color.value = c;

  const activate = (newActive = true) => {
    setColor(newActive ? "#FBFFB9" : "#FBFFB9");
    setActive(newActive);
    //Move();
  }

  const panHandler = useAnimatedGestureHandler({
    onStart: (_, ctx) => {
      ctx.startX = x.value;
      ctx.startY = y.value;
      ctx.dragged = false;

      if (ctx.aa != true) {
        ctx.aa = false; //이게 거짓이면 안움직이게 한다
      }

    },

    onActive: (event, ctx) => {
      if (ctx.dragged == false) {

        /* dragging를 처음 시작하게 된다면 */

        console.log("aaaaaaa");

        ctx.dragged = true;
        if (ctx.aa == false) {
          aaaaaa();
        }
      }
      if (ctx.aa == false) {
        x.value = ctx.startX + event.translationX;
        y.value = ctx.startY + event.translationY;
        console.log(ctx.aa);
      }
    },
    onFinish: (_, ctx) => {
      if (ctx.dragged == true) {
        /* dragging을 했다면 */
        console.log("bbbbbbbb");
        if (ctx.aa == false) {
          bbbbbb();
        }
        ctx.aa = true;
        console.log(ctx.aa);
      }
    }
  });

  const onTap = () => {
    //setChangeGir(null);
    props.activate(!active);
  }


  const animatedStyle = useAnimatedStyle(() => {
    return {
      borderRadius: 5,
      left: props.left,
      top: props.top,
      transform: [
        { translateX: x.value },
        { translateY: y.value },
        { scale: scale.value }
      ],
    }
  });

  if (props.name == "ele") {
    return (
      <PanGestureHandler onGestureEvent={panHandler} >
        <Animated.View style={[{ position: 'absolute' }, animatedStyle]} >
          <TouchableWithoutFeedback
            onPress={onTap} >
            <Image style={{ width: 50, height: 50 }} source={require('./assets/elephant.png')}></Image>
          </TouchableWithoutFeedback>
        </Animated.View>
      </PanGestureHandler>
    );
  }
  else if (props.name == "gir") {
    return (
      <PanGestureHandler onGestureEvent={panHandler} >
        <Animated.View style={[{ position: 'absolute' }, animatedStyle]} >
          <TouchableWithoutFeedback
            onPress={onTap} >
            <Image style={{ width: 50, height: 50 }} source={changeGir}></Image>
          </TouchableWithoutFeedback>
        </Animated.View>
      </PanGestureHandler>
    );
  }

  else if (props.name == "mon") {
    return (
      <PanGestureHandler onGestureEvent={panHandler} >
        <Animated.View style={[{ position: 'absolute' }, animatedStyle]} >
          <TouchableWithoutFeedback
            onPress={onTap} >
            <Image style={{ width: 50, height: 50 }} source={require('./assets/monkey.png')}></Image>
          </TouchableWithoutFeedback>
        </Animated.View>
      </PanGestureHandler>
    );
  }

  else if (props.name == "pen") {
    return (
      <PanGestureHandler onGestureEvent={panHandler} >
        <Animated.View style={[{ position: 'absolute' }, animatedStyle]} >
          <TouchableWithoutFeedback
            onPress={onTap} >
            <Image style={{ width: 50, height: 50 }} source={require('./assets/penguin.png')}></Image>
          </TouchableWithoutFeedback>
        </Animated.View>
      </PanGestureHandler>
    );
  }

  else if (props.name == "tiger") {
    return (
      <PanGestureHandler onGestureEvent={panHandler} >
        <Animated.View style={[{ position: 'absolute' }, animatedStyle]} >
          <TouchableWithoutFeedback
            onPress={onTap} >
            <Image style={{ width: 50, height: 50 }} source={require('./assets/tiger.png')}></Image>
          </TouchableWithoutFeedback>
        </Animated.View>
      </PanGestureHandler>
    );
  }

  else if (props.name == "lion") {
    return (
      <PanGestureHandler onGestureEvent={panHandler} >
        <Animated.View style={[{ position: 'absolute' }, animatedStyle]} >
          <TouchableWithoutFeedback
            onPress={onTap} >
            <Image style={{ width: 50, height: 50 }} source={require('./assets/lion.png')}></Image>
          </TouchableWithoutFeedback>
        </Animated.View>
      </PanGestureHandler>
    );
  }

  else if (props.name == "dragon") {
    return (
      <PanGestureHandler onGestureEvent={panHandler} >
        <Animated.View style={[{ position: 'absolute' }, animatedStyle]} >
          <TouchableWithoutFeedback
            onPress={onTap} >
            <Image style={{ width: 50, height: 50 }} source={require('./assets/dragon.png')}></Image>
          </TouchableWithoutFeedback>
        </Animated.View>
      </PanGestureHandler>
    );
  }

  else if (props.name == "chameleon") {
    return (
      <PanGestureHandler onGestureEvent={panHandler} >
        <Animated.View style={[{ position: 'absolute' }, animatedStyle]} >
          <TouchableWithoutFeedback
            onPress={onTap} >
            <Image style={{ width: 50, height: 50 }} source={require('./assets/chameleon.png')}></Image>
          </TouchableWithoutFeedback>
        </Animated.View>
      </PanGestureHandler>
    );
  }

  else if (props.name == "sunfish") {
    return (
      <PanGestureHandler onGestureEvent={panHandler} >
        <Animated.View style={[{ position: 'absolute' }, animatedStyle]} >
          <TouchableWithoutFeedback
            onPress={onTap} >
            <Image style={{ width: 50, height: 50 }} source={require('./assets/sunfish.png')}></Image>
          </TouchableWithoutFeedback>
        </Animated.View>
      </PanGestureHandler>
    );
  }
}

function HomeScreen({ navigation }) { //타이틀 화면
  return (

    <View style={[styles.container, { backgroundColor: '#FBFFB9' }]} >
      <StatusBar hidden={true} />
      <Text style={{ fontSize: 80 }} >노아의 방</Text>
      <Text style={{ fontSize: 80 }} >ZOO</Text>
      <Image
        style={{ height: 200, width: 200, resizeMode: 'contain' }}
        source={require('./assets/Title_Image.png')} />
      <Text style={{ fontSize: 80 }} ></Text>
      <Button mode="contained" compact="true" color="brown" contentStyle={{ height: 40, width: 200 }}
        labelStyle={{ color: "white", fontSize: 30 }} onPress={() => navigation.navigate('Main')} >START
        </Button>
    </View>
  );
}

const MainScreen = ({ navigation, route }) => { //메인화면 
  const moveToAnimal = () => {
    navigation.navigate("Animal", {
      post: Money, ele: eleMoney, gir: girMoney, mon: monMoney, pen: penMoney,
      tigBool: tigerBool, tigNum: tigerNum,
      lionBool: lionBool, lionNum: lionNum,
      dragonBool: dragonBool, dragonNum: dragonNum,
      chameleonBool: chameleonBool, chameleonNum: chameleonNum,
      sunfishBool: sunfishBool, sunfishNum: sunfishNum
    })
  }
  const moveToStore = () => {
    navigation.navigate("Store", {post: Money, buyBool: buyBool});  //편의시설(건물 상점)
  }
  const moveToZooKeeper = () => {
    navigation.navigate("ZooKeeper", {post : Money, 
                                      eleMan : eleMan, eleManMoney: eleManMoney,
                                      girMan : girMan, girManMoney: girManMoney,
                                      monMan : monMan, monManMoney: monManMoney,
                                      penMan : penMan, penManMoney: penManMoney,
                                      tigerMan : tigerMan, tigerManMoney : tigerManMoney,
                                      lionMan : lionMan, lionManMoney : lionManMoney,
                                      dragonMan : dragonMan, dragonManMoney: dragonManMoney,
                                      chameleonMan : chameleonMan, chameleonManMoney : chameleonManMoney,
                                      sunfishMan : sunfishMan, sunfishManMoney: sunfishManMoney});  //직원
  }

  const moveToAnimalBook = () => {
      navigation.navigate("AnimalBook", { ele: eleMoney, gir: girMoney, mon: monMoney, pen: penMoney,
                                          tigNum: tigerNum, lionNum: lionNum,dragonNum: dragonNum, chameleonNum: chameleonNum, sunfishNum: sunfishNum });  //도감
  }
  const moveToQuest = () => {
    navigation.navigate("Quest", {
                                  qusetMaingold: qusetMain, MainNum: countMainNum, countHome: countHome,
                                  quest2: quest2, quest2Count:quest2Count,
                                  quest3: quest3, quest3Count: quest3Count, post : Money,
                                  quest4: quest4, quest4Count: quest4Count
    });  //업적
  }

  const moveToRoulette = () => {
    navigation.navigate("Roulette", {
      post: Money,
      tigBool: tigerBool, tigNum: tigerNum,
      lionBool: lionBool, lionNum: lionNum,
      dragonBool: dragonBool, dragonNum: dragonNum,
      chameleonBool: chameleonBool, chameleonNum: chameleonNum,
      sunfishBool: sunfishBool, sunfishNum: sunfishNum
    })
  }

  const moveToMiniGame = () => {
    if (eleMan > 0) {
      navigation.navigate("MiniGame")
    }
    else
    {
      MinigameDialog();
    }
  }

  const MinigameDialog = () =>{
    setVisible_10(true);
  }

  const MinigameDialogCancle = () => {
    setVisible_10(false);
  }
 

  const [visible_10, setVisible_10] = useState(false);



  const [visible, setVisible] = useState(false);  //다이얼로그 창(게임종료 여부)
  const [visible_2, setVisible_2] = useState(false);
  const [visible_3, setVisible_3] = useState(false);
  const [visible_4, setVisible_4] = useState(false);

  const [visible_5, setVisible_5] = useState(false);
  const [visible_6, setVisible_6] = useState(false);
  const [visible_7, setVisible_7] = useState(false);
  const [visible_8, setVisible_8] = useState(false);
  const [visible_9, setVisible_9] = useState(false);

  //코끼리 설치 ui 띄우기
  const showDialogEle = () => {
    if (getEle == 1) {
      setVisible(true);
    }
  };
  const handleCancel = () => {
    setVisible(false);
  };
  //기린 설치 ui 띄우기
  const showDialogGir = () => {
    if (getGir == 1) {
      setVisible_2(true);
    }
  };
  const handleCancel_2 = () => {
    setVisible_2(false);
  };
  //원숭이 설치 ui 띄우기
  const showDialogMon = () => {
    if (getMon == 1) {
      setVisible_3(true);
    }
  };
  const handleCancel_3 = () => {
    setVisible_3(false);
  };

  //팽귄 설치 ui 띄우기
  const showDialogPen = () => {
    if (getPen == 1) {
      setVisible_4(true);
    }
  };
  const handleCancel_4 = () => {
    setVisible_4(false);
  };

  //호랑이 설치 ui 띄우기
  const showDialogTiger = () => {
    if (getTiger == 1) {
      setVisible_5(true);
    }
  };
  const handleCancel_5 = () => {
    setVisible_5(false);
  };
  //사자
  const showDialogLion = () => {
    if (getLion == 1) {
      setVisible_6(true);
    }
  };
  const handleCancel_6 = () => {
    setVisible_6(false);
  };
  //용
  const showDialogDragon = () => {
    if (getDragon == 1) {
      setVisible_7(true);
    }
  };
  const handleCancel_7 = () => {
    setVisible_7(false);
  };
  //카멜레온
  const showDialogChameleon = () => {
    if (getChameleon == 1) {
      setVisible_8(true);
    }
  };
  const handleCancel_8 = () => {
    setVisible_8(false);
  };
  //개복치
  const showDialogSunfish = () => {
    if (getSunfish == 1) {
      setVisible_9(true);
    }
  };
  const handleCancel_9 = () => {
    setVisible_9(false);
  };



  //모달관련
  const [modalVisible, setModalVisible] = useState(false);
  const [soundModalVisible, setSoundModalVisible] = useState(false);
  const [explnModalVisible, setExplnModalVisible] = useState(false);
  const [In, setIn] = useState(false);
  const [endMoneyModalVisible, setendMoneyModalVisible] = useState(true);

  const offSetonSound = () => {
    setSoundModalVisible(true);
    setModalVisible(false);
  }

  const offSetonExpln = () => {
    setExplnModalVisible(true);
    setModalVisible(false);
  }

  const offSoundonSet = () => {
    setSoundModalVisible(false);
    setModalVisible(true);
  }

  const offExplnonSet = () => {
    setExplnModalVisible(false);
    setModalVisible(true);
  }

  const offEndMoneySet = () => {
    setendMoneyModalVisible(false);
  }






  //돈 
  const [Money, setCounter] = useState(0);     //돈 증가 감소

  const [eleMoney, setEleMoney] = useState(100);     //코끼리 돈 증가 감소
  const [girMoney, setGirMoney] = useState(200);     //기린 돈 증가 감소
  const [monMoney, setMonMoney] = useState(300);     //원숭이 돈 증가 감소
  const [penMoney, setPenMoney] = useState(400);     //펭귄 돈 증가 감소


  const [addEleMoney, setEleAdd] = useState(0);      //코끼리 업그레이드 했을때 추가되는 돈
  const [addGirMoney, setGirAdd] = useState(0);      //기린 업그레이드 했을때 추가되는 돈
  const [addMonMoney, setMonAdd] = useState(0);      //원숭이 업그레이드 했을때 추가되는 돈
  const [addPenMoney, setPenAdd] = useState(0);      //펭귄 업그레이드 했을때 추가되는 돈
  const [addTigerMoney, setTigerAdd] = useState(0);      //호랑이 업그레이드 했을때 추가되는 돈
  const [addLionMoney, setLionAdd] = useState(0);      //사자 업그레이드 했을때 추가되는 돈
  const [addDragonMoney, setDragonAdd] = useState(0);      //용 업그레이드 했을때 추가되는 돈
  const [addChameleonMoney, setChameleonAdd] = useState(0);      //카멜레온 업그레이드 했을때 추가되는 돈
  const [addSunfishMoney, setSunfishAdd] = useState(0);      //개복치 업그레이드 했을때 추가되는 돈


  const [getEle, setEle] = useState(0);     //코끼리 구매 했는지 안했는지
  const [getGir, setGir] = useState(0);     //기린 구매 했는지 안했는지
  const [getMon, setMon] = useState(0);     //원숭이 구매 했는지 안했는지
  const [getPen, setPen] = useState(0);     //펭귄 구매 했는지 안했는지

  const [getTiger, setTiger] = useState(0);     //
  const [getLion, setLion] = useState(0);     //
  const [getDragon, setDragon] = useState(0);     //
  const [getChameleon, setChameleon] = useState(0);     //
  const [getSunfish, setSunfish] = useState(0);     //


  const [imgEle, setImgEle] = useState(require('./assets/lock.png')); //코끼리 인벤토리 사진 변경
  const [imgGir, setImgGir] = useState(require('./assets/lock.png')); //기린 인벤토리 사진 변경
  const [imgMon, setImgMon] = useState(require('./assets/lock.png')); //원숭이 인벤토리 사진 변경
  const [imgPen, setImgPen] = useState(require('./assets/lock.png')); //펭귄 인벤토리 사진 변경

  const [imgTiger, setImgTiger] = useState(require('./assets/lock.png')); //펭귄 인벤토리 사진 변경
  const [imgLion, setImgLion] = useState(require('./assets/lock.png')); //펭귄 인벤토리 사진 변경
  const [imgDragon, setImgDragon] = useState(require('./assets/lock.png')); //펭귄 인벤토리 사진 변경
  const [imgChameleon, setImgChameleon] = useState(require('./assets/lock.png')); //펭귄 인벤토리 사진 변경
  const [imgSunfish, setImgSunfish] = useState(require('./assets/lock.png')); //펭귄 인벤토리 사진 변경  

  //메인건물 눌렀을 때 실행
  const increaseCounter = () => {
    //상점에서 사는거
    if (eleMoney > 100) {
      setEleAdd((eleMoney - 20) / 10);
    }
    if (girMoney > 200) {
      setGirAdd((girMoney - 40) / 10);
    }
    if (monMoney > 300) {
      setMonAdd((monMoney - 60) / 10);
    }
    if (penMoney > 400) {
      setPenAdd((penMoney - 80) / 10);
    }

    //뽑기에서 나오는거
    if (tigerNum) {
      setTigerAdd((400 + 200 * (tigerNum - 1)) / 10);
    }
    if (lionNum) {
      setLionAdd((600 + 200 * (lionNum - 1)) / 10);
    }
    if (dragonNum) {
      setDragonAdd((800 + 200 * (dragonNum - 1)) / 10);
    }
    if (chameleonNum) {
      setChameleonAdd((1000 + 200 * (chameleonNum - 1)) / 10);
    }
    if (sunfishNum) {
      setSunfishAdd((2000 + 200 * (sunfishNum - 1)) / 10);
    }

    setCountHome(countHome + 1);

    setCounter(Money + (addEleMoney + addGirMoney + addMonMoney + addPenMoney +
      addTigerMoney + addLionMoney + addDragonMoney + addChameleonMoney + addSunfishMoney + 
      100)*((buyBool*0.5)+1) ); 

    if (countHome >= 9) {
      console.log(countHome);
    }
    else {
      //setBoolButton(false);
      console.log(countHome);
    }
  }



  //동물 상점에서 받아오는 거

  //동물 상점에서 받아오는 돈.
  useEffect(() => {
    if (route.params?.aaaa) {
      setCounter(route.params?.aaaa);
    }
    else if (route.params?.aaaa == 0) {
      setCounter(0);
    }
  }, [route.params?.aaaa]);

  //eleMoney값 받아오기
  useEffect(() => {
    if (route.params?.ele) {
      setEleMoney(route.params?.ele);
      if (route.params?.ele >= 120) {
        setEle(1);
        setImgEle(require('./assets/elephant.png')); //인벤토리 사진변경
      }
    }
  }, [route.params?.ele]);

  //girMoney값 받아오기
  useEffect(() => {
    if (route.params?.gir) {
      setGirMoney(route.params?.gir);
      if (route.params?.gir >= 240) {
        setGir(1);
        setImgGir(require('./assets/giraffe.png'));
      }
    }
  }, [route.params?.gir]);

  //monMoney값 받아오기
  useEffect(() => {
    if (route.params?.mon) {
      setMonMoney(route.params?.mon);
      if (route.params?.mon >= 360) {
        setMon(1);
        setImgMon(require('./assets/monkey.png'));
      }
    }
  }, [route.params?.mon]);

  //penMoney값 받아오기
  useEffect(() => {
    if (route.params?.pen) {
      setPenMoney(route.params?.pen);
      if (route.params?.pen >= 480) {
        setPen(1);
        setImgPen(require('./assets/penguin.png'));
      }
    }
  }, [route.params?.pen]);





  const [buyBool, setBuyBool] = useState(0);

  const [homeImage, setHomeImage] = useState(require('./assets/Home.png'));

  
  

  //상점에서 샀는지 판단
  useEffect(() => {
    if (route.params?.buyBool) {     
      setBuyBool(route.params?.buyBool);
      if(route.params?.buyBool == 1)
      {
        setHomeImage(require('./assets/home2.png'));
      }
      else if (route.params?.buyBool == 2)
      {
        setHomeImage(require('./assets/home3.png'));     
      }
      else if (route.params?.buyBool == 3)
      {
        setHomeImage(require('./assets/home4.png'));     
      }
      else if (route.params?.buyBool == 4)
      {
        setHomeImage(require('./assets/home5.png'));     
      }
      else if (route.params?.buyBool == 5)
      {
        setHomeImage(require('./assets/home6.png'));     
      }
    }
  }, [route.params?.buyBool]);

  

  //미니게임 돈 받아오는거
  useEffect(() => {
    if (route.params?.MiniGameMoney) {
      setCounter(Money + route.params?.MiniGameMoney * 100)
      GameCount = 0;
    }

  }, [route.params?.MiniGameMoney]);





  //뽑기관련
  const [tigerBool, setTigerBool] = useState(false); //호랑이 뽑기로 나온지 체크
  const [lionBool, setLoinBool] = useState(false); //사자 뽑기로 나온지 체크
  const [dragonBool, setDragonBool] = useState(false); //용 뽑기로 나온지 체크
  const [chameleonBool, setChameleonBool] = useState(false); //카멜레온 뽑기로 나온지 체크
  const [sunfishBool, setSunfishBool] = useState(false); //개복치 뽑기로 나온지 체크

  const [tigerNum, setTigerNum] = useState(0); //호랑이 뽑은 수 체크
  const [lionNum, setLionNum] = useState(0); //사자 뽑은 수 체크
  const [dragonNum, setDragonNum] = useState(0); //용 뽑은 수 체크
  const [chameleonNum, setChameleonNum] = useState(0); //카멜레온 뽑은 수 체크
  const [sunfishNum, setSunfishNum] = useState(0); //개복치 뽑은 수 체크

  //호랑이
  useEffect(() => {
    if (route.params?.tigBool) {
      setTigerBool(route.params?.tigBool);
    }
  }, [route.params?.tigBool]);
  useEffect(() => {
    if (route.params?.tigNum) {
      setTigerNum(route.params?.tigNum);
      setImgTiger(require('./assets/tiger.png')); //인벤토리 사진변경
      setTiger(1);
    }
  }, [route.params?.tigNum]);

  //사자
  useEffect(() => {
    if (route.params?.lionBool) {
      setLoinBool(route.params?.lionBool);
    }
  }, [route.params?.lionBool]);
  useEffect(() => {
    if (route.params?.lionNum) {
      setLionNum(route.params?.lionNum);
      setImgLion(require('./assets/lion.png')); //인벤토리 사진변경
      setLion(1);
    }

  }, [route.params?.lionNum]);

  //용
  useEffect(() => {
    if (route.params?.dragonBool) {
      setDragonBool(route.params?.dragonBool);
    }
  }, [route.params?.dragonBool]);
  useEffect(() => {
    if (route.params?.dragonNum) {
      setDragonNum(route.params?.dragonNum);
      setImgDragon(require('./assets/dragon.png')); //인벤토리 사진변경
      setDragon(1);
    }

  }, [route.params?.dragonNum]);

  //카멜레온
  useEffect(() => {
    if (route.params?.chameleonBool) {
      setChameleonBool(route.params?.chameleonBool);
    }
  }, [route.params?.chameleonBool]);
  useEffect(() => {
    if (route.params?.chameleonNum) {
      setChameleonNum(route.params?.chameleonNum);
      setImgChameleon(require('./assets/chameleon.png')); //인벤토리 사진변경
      setChameleon(1);
    }

  }, [route.params?.chameleonNum]);

  //개복치
  useEffect(() => {
    if (route.params?.sunfishBool) {
      setSunfishBool(route.params?.sunfishBool);
    }
  }, [route.params?.sunfishBool]);
  useEffect(() => {
    if (route.params?.sunfishNum) {
      setSunfishNum(route.params?.sunfishNum);
      setImgSunfish(require('./assets/sunfish.png')); //인벤토리 사진변경
      setSunfish(1);
    }

  }, [route.params?.sunfishNum]);

  //뽑기에서 받아오는 돈
  useEffect(() => {
    if (route.params?.post) {
      setCounter(route.params?.post);
    }
    else if(route.params?.post == 0)
    {
      setCounter(0);
    }
  }, [route.params?.post]);

  //편의시설 받아오는 돈
  useEffect(() => {
    if (route.params?.storemoney) {
      setCounter(route.params?.storemoney);
    }
    else if (route.params?.storemoney == 0) {
      setCounter(0);
    }
  }, [route.params?.storemoney]);


  

  const [eleMan, setEleMan] = useState(0); // 직원 코끼리 수.
  const [girMan, setGirMan] = useState(0); // 직원 기린 수.
  const [monMan, setMonMan] = useState(0); // 직원 원숭이 수
  const [penMan, setPenMan] = useState(0); // 직원 펭귄 수
  const [tigerMan, setTigerMan] = useState(0); // 직원 호랑이 수
  const [lionMan, setLionMan] = useState(0); //직원 사자 수
  const [dragonMan, setDragonMan] = useState(0); //직원 드래곤 수
  const [chameleonMan, setChameleonMan] = useState(0); // 직원 카멜레온 수
  const [sunfishMan, setSunfishMan] = useState(0); // 직원 개복치 수



  const [eleManMoney, setEleManMoney] = useState(1000);
  const [girManMoney, setGirManMoney] = useState(3000);
  const [monManMoney, setMonManMoney] = useState(5000);
  const [penManMoney, setPenManMoney] = useState(8000);
  const [tigerManMoney, setTigerManMoney] = useState(10000);
  const [lionManMoney, setLionManMoney] = useState(15000);
  const [dragonManMoney, setDragonManMoney] = useState(20000);
  const [chameleonManMoney, setChameleonManMoney] = useState(35000);
  const [sunfishManMoney, setSunfishManMoney] = useState(50000);

  // 직원에서 받아오는 돈
  useEffect(() => {
    if (route.params?.ManMoney) {
      setCounter(route.params?.ManMoney);
    }
    else if (route.params?.ManMoney == 0)
    {
      setCounter(0);
    }

    //코끼리
    if (route.params?.eleMan)
    {
      setEleMan(route.params?.eleMan);
    }
    if (route.params?.eleManMoney)
    {
      setEleManMoney(route.params?.eleManMoney);
    }
    //기린
    if (route.params?.girMan)
    {
      setGirMan(route.params?.girMan);
    }
    if (route.params?.girManMoney)
    {
      setGirManMoney(route.params?.girManMoney);
    }
    //원숭이
    if (route.params?.monMan)
    {
      setMonMan(route.params?.monMan);
    }
    if (route.params?.monManMoney)
    {
      setMonManMoney(route.params?.monManMoney);
    }
    // 펭귄
    if (route.params?.penMan)
    {
      setPenMan(route.params?.penMan);
    }
    if (route.params?.penManMoney)
    {
      setPenManMoney(route.params?.penManMoney);
    }
    //호랑이
    if (route.params?.tigerMan)
    {
      setTigerMan(route.params?.tigerMan);
    }
    if (route.params?.tigerManMoney)
    {
      setTigerManMoney(route.params?.tigerManMoney);
    }
    //사자
    if (route.params?.lionMan)
    {
      setLionMan(route.params?.lionMan);
    }
    if (route.params?.lionManMoney)
    {
      setLionManMoney(route.params?.lionManMoney);
    }
    //용
    if (route.params?.dragonMan)
    {
      setDragonMan(route.params?.dragonMan);
    }
    if (route.params?.dragonManMoney)
    {
      setDragonManMoney(route.params?.dragonManMoney);
    }
    //카멜레온
    if (route.params?.chameleonMan)
    {
      setChameleonMan(route.params?.chameleonMan);
    }
    if (route.params?.chameleonManMoney)
    {
      setChameleonManMoney(route.params?.chameleonManMoney);
    }
    //개복치
    if (route.params?.sunfishMan)
    {
      setSunfishMan(route.params?.sunfishMan);
    }
    if (route.params?.sunfishManMoney)
    {
      setSunfishManMoney(route.params?.sunfishManMoney);
    }


    
    
  }, [route.params?.eleMan, route.params?.eleManMoney,
    route.params?.girMan, route.params?.girManMoney,
    route.params?.monMan, route.params?.monManMoney,
    route.params?.penMan, route.params?.penManMoney,
    route.params?.tigerMan, route.params?.tigerManMoney,
    route.params?.lionMan, route.params?.lionManMoney,
    route.params?.dragonMan, route.params?.dragonManMoney,
    route.params?.chameleonMan, route.params?.chameleonManMoney,
    route.params?.sunfishMan, route.params?.sunfishManMoney,
  ]);





  useEffect(() => {
    if (route.params?.Animal) {

    }
  }, [route.params?.Animal]);




  //업적 
  useEffect(() => {
    if (route.params?.questMoney) {
      setCounter(route.params?.questMoney);
    }

    else if (route.params?.questMoney == 0){
      setCounter(0);
    }
    
  }, [route.params?.questMoney]);

  //퀘스트1
  useEffect(() => {
    if (route.params?.MainNum) {
      setCountMainNum(route.params?.MainNum);
    }
  }, [route.params?.MainNum]);

  useEffect(() => {
    if (route.params?.qusetMaingold) {
      
      setnumMain(route.params?.qusetMaingold);
      //setCounter(Money + route.params?.qusetMaingold);
    }
  }, [route.params?.qusetMaingold]);

  const [qusetMain, setnumMain] = useState(0);  // 퀘스트 보상 
  const [countMainNum, setCountMainNum] = useState(10); // 퀘스트 내용
  const [countHome, setCountHome] = useState(0); // 몇번눌렀는지 세는애 


  //퀘스트2 
  useEffect(() => {
    if (route.params?.quest2)
    {
      console.log(route.params?.quest2);
      setQuest2(route.params?.quest2);
      //setCounter(Money + route.params?.quest2);
    }

    if(route.params?.quest2Count)
    {
      setquset2Count(route.params?.quest2Count);
    }

  },[route.params?.quest2,route.params?.quest2Count]);

  const [quest2, setQuest2] = useState(0); //퀘스트2 보상
  const [quest2Count, setquset2Count] = useState(10); // 퀘스트2 내용



  //퀘스트3
  useEffect(() => {
    if (route.params?.quest3)
    {
      setQuest3(route.params?.quest3);
      //setCounter(Money + route.params?.quest3);
    }

    if(route.params?.quest3Count)
    {
      setquset3Count(route.params?.quest3Count);
    }

  },[route.params?.quest3,route.params?.quest3Count]);

  const [quest3, setQuest3] = useState(0); //퀘스트3 보상
  const [quest3Count, setquset3Count] = useState(50000); // 퀘스트3 내용


  //퀘스트4
  useEffect(() => {
    if (route.params?.quest4)
    {
      setQuest4(route.params?.quest4);
      //setCounter(Money + route.params?.quest4);
    }

    if(route.params?.quest4Count)
    {
      setquset4Count(route.params?.quest4Count);
    }

  },[route.params?.quest4,route.params?.quest4Count]);

  const [quest4, setQuest4] = useState(0); //퀘스트4 보상
  const [quest4Count, setquset4Count] = useState(1); // 퀘스트4 내용




  // 움직이는거 관련
  const [boxes, setBoxes] = useState([]); // react hook

  const intersect = (x, y, w, h, x1, y1, w1, h1) =>
    y + h >= y1 && y1 + h1 >= y && x + w >= x1 && x1 + w1 >= x;

  const cleanupAction = () => { }

  const add_Ele = () => {
    if (getEle != 0) {
      let myBoxes = [...boxes];
      myBoxes.push({
        name: "ele",
        left: 300, top: 100,
        width: 100, height: 100, active: false
      });
      setBoxes(myBoxes);
      setVisible(false);
      setEle(0);
    }
  }
  const add_Gir = () => {
    if (getGir != 0) {
      let myBoxes = [...boxes];
      myBoxes.push({
        name: "gir", //이름->생성하는 동물
        left: 300, top: 100, // 위치
        width: 100, height: 100, active: false
      });
      setBoxes(myBoxes);
      setVisible_2(false); //다이얼로그 닫는거
      setGir(0); // 변화
    }
  }
  const add_Mon = () => {
    if (getMon != 0) {
      let myBoxes = [...boxes];
      myBoxes.push({
        name: "mon", //이름->생성하는 동물
        left: 300, top: 100, // 위치
        width: 100, height: 100, active: false
      });
      setBoxes(myBoxes);
      setVisible_3(false); //다이얼로그 닫는거
      setMon(0); // 변화
    }
  }
  const add_Pen = () => {
    if (getPen != 0) {
      let myBoxes = [...boxes];
      myBoxes.push({
        name: "pen", //이름->생성하는 동물
        left: 300, top: 100, // 위치
        width: 100, height: 100, active: false
      });
      setBoxes(myBoxes);
      setVisible_4(false); //다이얼로그 닫는거
      setPen(0); // 변화
    }
  }

  const add_Tiger = () => {
    if (getTiger != 0) {
      let myBoxes = [...boxes];
      myBoxes.push({
        name: "tiger", //이름->생성하는 동물
        left: 300, top: 100, // 위치
        width: 100, height: 100, active: false
      });
      setBoxes(myBoxes);
      setVisible_5(false); //다이얼로그 닫는거
      setTiger(0); // 변화
    }
  }

  const add_Lion = () => {
    if (getLion != 0) {
      let myBoxes = [...boxes];
      myBoxes.push({
        name: "lion", //이름->생성하는 동물
        left: 300, top: 100, // 위치
        width: 100, height: 100, active: false
      });
      setBoxes(myBoxes);
      setVisible_6(false); //다이얼로그 닫는거
      setLion(0); // 변화
    }
  }

  const add_Dragon = () => {
    if (getDragon != 0) {
      let myBoxes = [...boxes];
      myBoxes.push({
        name: "dragon", //이름->생성하는 동물
        left: 300, top: 100, // 위치
        width: 100, height: 100, active: false
      });
      setBoxes(myBoxes);
      setVisible_7(false); //다이얼로그 닫는거
      setDragon(0); // 변화
    }
  }

  const add_Chameleon = () => {
    if (getChameleon != 0) {
      let myBoxes = [...boxes];
      myBoxes.push({
        name: "chameleon", //이름->생성하는 동물
        left: 300, top: 100, // 위치
        width: 100, height: 100, active: false
      });
      setBoxes(myBoxes);
      setVisible_8(false); //다이얼로그 닫는거
      setChameleon(0); // 변화
    }
  }

  const add_Sunfish = () => {
    if (getSunfish != 0) {
      let myBoxes = [...boxes];
      myBoxes.push({
        name: "sunfish", //이름->생성하는 동물
        left: 300, top: 100, // 위치
        width: 100, height: 100, active: false
      });
      setBoxes(myBoxes);
      setVisible_9(false); //다이얼로그 닫는거
      setSunfish(0); // 변화
    }
  }


















  const remove = () => {
    let myBoxes = boxes.filter((box) => box.active === false);
    setBoxes(myBoxes);
    setVisible_3(false);
  }

  const jump = () => {
    console.log("Boxes jump called");
  }
  const blink = () => { }

  const activate = (name, newActive) => {
    let myBoxes = [...boxes]; // spread operator ... 전개 연산자
    myBoxes.forEach((box) => {
      if (box.name == name)
        box.active = newActive;
    });
    setBoxes(myBoxes);
  }

  let boxesRender = [];
  for (let i = 0; i < boxes.length; i++) {
    let box = boxes[i];
    boxesRender.push(<Box name={box.name} key={box.name}
      left={box.left} top={box.top}
      width={box.width} height={box.height}
      active={box.active} action={box.action}
      cleanupAction={cleanupAction}
      activate={(flag) => activate(box.name, flag)}
    />
    );
  }




  return (

    <PaperProvider>
      <View style={{ flex: 1, backgroundColor: "#FBFFB9" }}>
        <StatusBar hidden={true} />

        <Modal
          animationType="fade"
          transparent={true}
          visible={false}
          onRequestClose={() => {
            Alert.alert('종료된 동안 번 돈이에요.');
          }}>
          <View style={styles.centeredView}>
            <View style={styles.EndMoneyView}>
              <View style={styles.SettingScreen}>
                <View style={{ flex: 1, alignItems: 'center' }}>
                  <Image style={{ height: 55, width: 55, resizeMode: 'contain', marginTop: 10 }} backgroundColor="#FBFFB9" source={require('./assets/dollar.png')} />
                </View>
              </View>
              <View style={{ flex: 4, justifyContent: 'center' }}>
                <Text style={{ textAlign: 'center', fontSize: 40 }}>종료 된 동안</Text>
                <Text style={{ textAlign: 'center', fontSize: 40 }}>1.1A 만큼 </Text>
                <Text style={{ textAlign: 'center', fontSize: 40 }}>벌었습니다!</Text>
              </View>
              <View style={{ flex: 1, flexDirection: 'row' }}>
                <View>
                  <Button contentStyle={{ height: 50, width: 100, }} labelStyle={{ color: "white", fontSize: 20 }}
                    color='#754F44' mode="contained" onPress={() => offEndMoneySet()}> 확인 </Button>
                </View>
              </View>
            </View>
          </View>
        </Modal>

        <Modal
          animationType="fade"
          transparent={true}
          visible={modalVisible}
          onRequestClose={() => {
            Alert.alert('Modal has been closed.');
          }}>
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <View style={styles.SettingScreen}>
                <Image style={{ height: 40, width: 40, resizeMode: 'contain', flex: 1 }} source={require('./assets/setting.png')} />
                <View style={{ flex: 2 }}>
                  <Text style={{ textAlign: 'center', fontSize: 30 }}>환경설정</Text>
                </View>

                <View style={{ width: 40, height: 40, flex: 1, alignItems: 'center', }}>
                  <TouchableOpacity onPress={() => {
                    setModalVisible(!modalVisible);
                  }}>
                    <Image style={{ height: 40, width: 40, resizeMode: 'contain' }} source={require('./assets/cancel.png')} />
                  </TouchableOpacity>
                </View>

              </View>
              <View style={{ flex: 1, flexDirection: 'row' }}>
                <View>
                  <Button contentStyle={{ height: 50, width: 130, }} labelStyle={{ color: "white", fontSize: 20 }} color="#754F44" mode="contained" onPress={() => offSetonSound()}> 소리설정 </Button>
                </View>
              </View>

              <View style={{ flex: 1, flexDirection: 'row' }}>
                <View>
                  <Button contentStyle={{ height: 50, width: 130, }} labelStyle={{ color: "white", fontSize: 20 }} color='#754F44' mode="contained" onPress={() => offSetonExpln()}> 게임설명 </Button>
                </View>
              </View>
            </View>
          </View>
        </Modal>

        <Modal
          animationType="fade"
          transparent={true}
          visible={soundModalVisible}
          onRequestClose={() => {
            Alert.alert('Modal has been closed.');
          }}>
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <View style={styles.SettingScreen}>
                <Image style={{ height: 40, width: 40, resizeMode: 'contain', flex: 1 }} source={require('./assets/setting.png')} />
                <View style={{ flex: 2 }}>
                  <Text style={{ textAlign: 'center', fontSize: 30 }}>소리설정</Text>
                </View>

                <View style={{ width: 40, height: 40, flex: 1, alignItems: 'center', }}>
                  <TouchableOpacity onPress={() => {
                    setSoundModalVisible(!soundModalVisible);
                  }}>
                    <Image style={{ height: 40, width: 40, resizeMode: 'contain' }} source={require('./assets/cancel.png')} />
                  </TouchableOpacity>
                </View>
              </View>
              <View>
                <View>
                  <Button contentStyle={{ height: 50, width: 130, }} labelStyle={{ color: "white", fontSize: 20 }} color='#754F44' mode="contained" onPress={() => offSoundonSet()}> 뒤로가기 </Button>
                </View>
              </View>
            </View>
          </View>
        </Modal>

        <Modal
          animationType="fade"
          transparent={true}
          visible={explnModalVisible}
          onSwipeComplete={setModalVisible}
          onRequestClose={() => {
            Alert.alert('Modal has been closed.');
          }}>
          <View style={styles.centeredView}>
            <View style={styles.modalView}>
              <View style={styles.SettingScreen}>
                <Image style={{ height: 40, width: 40, resizeMode: 'contain', flex: 1 }} source={require('./assets/setting.png')} />
                <View style={{ flex: 2, marginBottom: 80 }}>
                  <Text style={{ textAlign: 'center', fontSize: 30 }}>게임설명</Text>
                </View>
                <View style={{ width: 40, height: 40, flex: 1, alignItems: 'center', }}>
                  <TouchableOpacity onPress={() => {
                    setExplnModalVisible(!explnModalVisible);
                  }}>
                    <Image style={{ height: 40, width: 40, resizeMode: 'contain' }} source={require('./assets/cancel.png')} />
                  </TouchableOpacity>
                </View>
              </View>

              <View style={{ justifyContent: 'center', alignItems: 'center', flex: 7 }}>
                <Text style={{ fontSize: 25 }}>1. 메인 건물을 클릭해</Text>
                <Text style={{ fontSize: 25 }}>돈을 번다.</Text>
                <Text style={{ fontSize: 25 }}>2. 번 돈으로 동물, 건물</Text>
                <Text style={{ fontSize: 25 }}>직원을 구입한다.</Text>
                <Text style={{ fontSize: 25 }}>3. 업적 확인은 필수!</Text>
                <Text style={{ fontSize: 25 }}>4. 뽑기를 하면 좋은 일이</Text>
                <Text style={{ fontSize: 25 }}>생길지도?</Text>
              </View>
              <View>
                <View>
                  <Button contentStyle={{ height: 50, width: 130, }} labelStyle={{ color: "white", fontSize: 20 }} color='#754F44' mode="contained" onPress={() => offExplnonSet()}> 뒤로가기 </Button>
                </View>
              </View>
            </View>
          </View>
        </Modal>

        <Modal
          animationType="fade"
          transparent={true}
          visible={In}
          onRequestClose={() => {
            Alert.alert('Modal has been closed.');
          }}>
          <View style={styles.centeredView}>
            <View style={{ justifyContent: 'center', alignItems: 'center' }}>
              <View style={styles.InView}>

                <View style={{ width: 250, height: 40, justifyContent: 'flex-end', flexDirection: 'row', marginTop: 5 }}>
                  <TouchableOpacity onPress={() => {
                    setIn(!In);
                  }}>
                    <Image style={{ height: 40, width: 40, resizeMode: 'contain' }} source={require('./assets/cancel.png')} />
                  </TouchableOpacity>

                </View>
                <ScrollView>
                  <View style={{ width: 250, height: 500, margin: 10, }}>
                    <View style={{ backgroundColor: 'gray', flexDirection: 'row' }}>
                      <View style={{ width: 70, height: 100, backgroundColor: 'white', margin: 5, flex: 1, alignItems: 'center' }}>
                        <View style={{ flex: 3, justifyContent: 'center' }}>
                          <TouchableOpacity onPress={showDialogEle}>
                            <Image style={{ height: 50, width: 50, resizeMode: 'contain' }} source={imgEle} />
                          </TouchableOpacity>
                        </View>

                      </View>
                      <View style={{ width: 70, height: 100, backgroundColor: 'white', margin: 5, flex: 1, alignItems: 'center' }}>
                        <View style={{ flex: 3, justifyContent: 'center' }}>
                          <TouchableOpacity onPress={showDialogGir}>
                            <Image style={{ height: 50, width: 50, resizeMode: 'contain' }} source={imgGir} />
                          </TouchableOpacity>
                        </View>

                      </View>
                      <View style={{ width: 70, height: 100, backgroundColor: 'white', margin: 5, flex: 1, alignItems: 'center' }}>
                        <View style={{ flex: 3, justifyContent: 'center' }}>
                          <TouchableOpacity onPress={showDialogMon}>
                            <Image style={{ height: 50, width: 50, resizeMode: 'contain' }} source={imgMon} />
                          </TouchableOpacity>
                        </View>

                      </View>
                    </View>
                    <View style={{ backgroundColor: 'gray', flexDirection: 'row' }}>
                      <View style={{ width: 70, height: 100, backgroundColor: 'white', margin: 5, flex: 1, alignItems: 'center' }}>
                        <View style={{ flex: 3, justifyContent: 'center' }}>
                          <TouchableOpacity onPress={showDialogPen}>
                            <Image style={{ height: 50, width: 50, resizeMode: 'contain' }} source={imgPen} />
                          </TouchableOpacity>
                        </View>
                     
                      </View>
                      <View style={{ width: 70, height: 100, backgroundColor: 'white', margin: 5, flex: 1, alignItems: 'center' }}>
                        <View style={{ flex: 3, justifyContent: 'center' }}>
                          <TouchableOpacity onPress={showDialogTiger}>
                            <Image style={{ height: 50, width: 50, resizeMode: 'contain' }} source={imgTiger} />
                          </TouchableOpacity>
                        </View>
                   
                      </View>
                      <View style={{ width: 70, height: 100, backgroundColor: 'white', margin: 5, flex: 1, alignItems: 'center' }}>
                        <View style={{ flex: 3, justifyContent: 'center' }}>
                          <TouchableOpacity onPress={showDialogLion}>
                            <Image style={{ height: 50, width: 50, resizeMode: 'contain' }} source={imgLion} />
                          </TouchableOpacity>
                        </View>
                       
                      </View>
                    </View>
                    <View style={{ backgroundColor: 'gray', flexDirection: 'row' }}>
                      <View style={{ width: 70, height: 100, backgroundColor: 'white', margin: 5, flex: 1, alignItems: 'center' }}>
                        <View style={{ flex: 3, justifyContent: 'center' }}>
                          <TouchableOpacity onPress={showDialogDragon}>
                            <Image style={{ height: 50, width: 50, resizeMode: 'contain' }} source={imgDragon} />
                          </TouchableOpacity>
                        </View>
                      
                      </View>
                      <View style={{ width: 70, height: 100, backgroundColor: 'white', margin: 5, flex: 1, alignItems: 'center' }}>
                        <View style={{ flex: 3, justifyContent: 'center' }}>
                          <TouchableOpacity onPress={showDialogChameleon}>
                            <Image style={{ height: 50, width: 50, resizeMode: 'contain' }} source={imgChameleon} />
                          </TouchableOpacity>
                        </View>
                        
                      </View>
                      <View style={{ width: 70, height: 100, backgroundColor: 'white', margin: 5, flex: 1, alignItems: 'center' }}>
                        <View style={{ flex: 3, justifyContent: 'center' }}>
                          <TouchableOpacity onPress={showDialogSunfish}>
                            <Image style={{ height: 50, width: 50, resizeMode: 'contain' }} source={imgSunfish} />
                          </TouchableOpacity>
                        </View>
                       
                      </View>
                    </View>
                    <View style={{ backgroundColor: 'gray', flexDirection: 'row' }}>
                      <View style={{ width: 70, height: 100, backgroundColor: 'white', margin: 5, flex: 1, alignItems: 'center' }}>
                        <View style={{ flex: 3, justifyContent: 'center' }}>
                          <Image style={{ height: 50, width: 50, resizeMode: 'contain' }} source={require('./assets/lock.png')} />
                        </View>
                     
                      </View>
                      <View style={{ width: 70, height: 100, backgroundColor: 'white', margin: 5, flex: 1, alignItems: 'center' }}>
                        <View style={{ flex: 3, justifyContent: 'center' }}>
                          <Image style={{ height: 50, width: 50, resizeMode: 'contain' }} source={require('./assets/lock.png')} />
                        </View>
         
                      </View>
                      <View style={{ width: 70, height: 100, backgroundColor: 'white', margin: 5, flex: 1, alignItems: 'center' }}>
                        <View style={{ flex: 3, justifyContent: 'center' }}>
                          <Image style={{ height: 50, width: 50, resizeMode: 'contain' }} source={require('./assets/lock.png')} />
                        </View>

                      </View>
                    </View>


                  </View>
                </ScrollView>


              </View>
            </View>
          </View>
        </Modal>


        <Dialog.Container onBackdropPress={handleCancel} visible={visible}>
          <Dialog.Title>코끼리 다이얼로그</Dialog.Title>
          <Dialog.Input>소환할거냐 안할거냐!</Dialog.Input>
          <Dialog.Button label="아니요" onPress={handleCancel} />
          <Dialog.Button label="예" onPress={add_Ele} />
        </Dialog.Container>

        <Dialog.Container onBackdropPress={handleCancel_2} visible={visible_2}>
          <Dialog.Title>기린 다이얼로그</Dialog.Title>
          <Dialog.Input>소환할거냐 안할거냐!</Dialog.Input>
          <Dialog.Button label="아니요" onPress={handleCancel_2} />
          <Dialog.Button label="예" onPress={add_Gir} />
        </Dialog.Container>

        <Dialog.Container onBackdropPress={handleCancel_3} visible={visible_3}>
          <Dialog.Title>원숭이 다이얼로그</Dialog.Title>
          <Dialog.Input>소환할거냐 안할거냐!</Dialog.Input>
          <Dialog.Button label="아니요" onPress={handleCancel_3} />
          <Dialog.Button label="예" onPress={add_Mon} />
        </Dialog.Container>

        <Dialog.Container onBackdropPress={handleCancel_4} visible={visible_4}>
          <Dialog.Title>팽귄 다이얼로그</Dialog.Title>
          <Dialog.Input>소환할거냐 안할거냐!</Dialog.Input>
          <Dialog.Button label="아니요" onPress={handleCancel_4} />
          <Dialog.Button label="예" onPress={add_Pen} />
        </Dialog.Container>

        <Dialog.Container onBackdropPress={handleCancel_5} visible={visible_5}>
          <Dialog.Title>호랑이 다이얼로그</Dialog.Title>
          <Dialog.Input>소환할거냐 안할거냐!</Dialog.Input>
          <Dialog.Button label="아니요" onPress={handleCancel_5} />
          <Dialog.Button label="예" onPress={add_Tiger} />
        </Dialog.Container>

        <Dialog.Container onBackdropPress={handleCancel_6} visible={visible_6}>
          <Dialog.Title>사자 다이얼로그</Dialog.Title>
          <Dialog.Input>소환할거냐 안할거냐!</Dialog.Input>
          <Dialog.Button label="아니요" onPress={handleCancel_6} />
          <Dialog.Button label="예" onPress={add_Lion} />
        </Dialog.Container>

        <Dialog.Container onBackdropPress={handleCancel_7} visible={visible_7}>
          <Dialog.Title>용 다이얼로그</Dialog.Title>
          <Dialog.Input>소환할거냐 안할거냐!</Dialog.Input>
          <Dialog.Button label="아니요" onPress={handleCancel_7} />
          <Dialog.Button label="예" onPress={add_Dragon} />
        </Dialog.Container>

        <Dialog.Container onBackdropPress={handleCancel_8} visible={visible_8}>
          <Dialog.Title>카멜레온 다이얼로그</Dialog.Title>
          <Dialog.Input>소환할거냐 안할거냐!</Dialog.Input>
          <Dialog.Button label="아니요" onPress={handleCancel_8} />
          <Dialog.Button label="예" onPress={add_Chameleon} />
        </Dialog.Container>

        <Dialog.Container onBackdropPress={handleCancel_9} visible={visible_9}>
          <Dialog.Title>개복치 다이얼로그</Dialog.Title>
          <Dialog.Input>소환할거냐 안할거냐!</Dialog.Input>
          <Dialog.Button label="아니요" onPress={handleCancel_9} />
          <Dialog.Button label="예" onPress={add_Sunfish} />
        </Dialog.Container>


        <Dialog.Container onBackdropPress={MinigameDialogCancle} visible={visible_10}>
          <Dialog.Title>미니게임 알림</Dialog.Title>
          <Dialog.Input>코끼리를 구매하지 못해서 못들어가요</Dialog.Input>
          <Dialog.Button label="확인" onPress={MinigameDialogCancle} />
        </Dialog.Container>


        <View style={styles.TopStyle}>
          <Image style={{ height: 40, width: 40, resizeMode: 'contain' }} backgroundColor="#FBFFB9" source={require('./assets/dollar.png')} />

          <Text style={{ height: 40, width: 250, alignItems: 'center', justifyContent: 'center', fontSize: 30 }}>  {Money} </Text>

          <Button icon={require('./assets/medal.png')} mode="contained" compact="true" color="#754F44" contentStyle={{ height: 40, width: 40 }}
            labelStyle={{ color: "white", fontSize: 20 }} onPress={moveToQuest} >
          </Button>
          <Button icon={require('./assets/book.png')} mode="contained" compact="true" color="#FFD292" contentStyle={{ height: 40, width: 40 }}
            labelStyle={{ color: "white", fontSize: 20 }} onPress={moveToAnimalBook}>
          </Button>
          <Button icon={require('./assets/setting.png')} mode="contained" compact="true" color="#EC7357" contentStyle={{ height: 40, width: 40 }}
            labelStyle={{ color: "white", fontSize: 20 }} onPress={() => {
              setModalVisible(true);
            }}>
          </Button>
        </View>



        <View style={{ flex: 6 }}>

          <ImageBackground style={{ resizeMode: 'cover', justifyContent: 'center', flex: 1 }}>
            <View style={styles.MainScreenStyle}>
              <TouchableOpacity
                onPress={increaseCounter}>
                <Image
                  style={{ height: 200, width: 200, resizeMode: 'contain' }}
                  source={homeImage} />
              </TouchableOpacity>
            </View>



            <View style={{ height: 50, width: 50, alignItems: 'flex-end', left: 350, top: 100 }}>
              <TouchableOpacity onPress={() => setIn(true)}>
                <Image source={require('./assets/bag.png')} style={{ height: 50, width: 50 }}></Image>
              </TouchableOpacity>
              <Text></Text>
              <TouchableOpacity onPress={moveToMiniGame}>
                <Image source={require('./assets/firework.png')} style={{ height: 50, width: 50 }}></Image>
              </TouchableOpacity>

            </View>
          </ImageBackground>
        </View>

        {boxesRender}


        <View style={styles.ButtenStyle}>
          <Button icon={require('./assets/Title_Image.png')} mode="contained" compact="true" color="gray" contentStyle={{ height: 45, width: 103.5 }}
            labelStyle={{ color: "white", fontSize: 18 }} onPress={moveToAnimal}>
            동물
      </Button>
          <Button icon={require('./assets/building.png')} mode="contained" compact="true" color="gray" contentStyle={{ height: 45, width: 103.5 }}
            labelStyle={{ color: "white", fontSize: 18 }} onPress={moveToStore}>
            편의시설
      </Button>
          <Button icon={require('./assets/zookeeper.png')} mode="contained" compact="true" color="gray" contentStyle={{ height: 45, width: 103.5 }}
            labelStyle={{ color: "white", fontSize: 18 }} onPress={moveToZooKeeper}>
            직원
      </Button>
          <Button icon={require('./assets/Egg.png')} mode="contained" compact="true" color="gray" contentStyle={{ height: 45, width: 103.5 }}
            labelStyle={{ color: "white", fontSize: 18 }} onPress={moveToRoulette}>
            뽑기
      </Button>
        </View>
      </View>
    </PaperProvider>
  );
}

function AnimalScreen({ navigation, route }) { //동물 씬

  const moveToMain = () => {
    navigation.navigate("Main", {
      postnum: visible, aaaa: Money, ele: eleMoney, gir: girMoney, mon: monMoney, pen: penMoney,
      tigBool: tigerBool, tigNum: tigerNum,
      lionBool: lionBool, lionNum: lionNum,
      dragonBool: dragonBool, dragonNum: dragonNum,
      chameleonBool: chameleonBool, chameleonNum: chameleonNum,
      sunfishBool: sunfishBool, sunfishNum: sunfishNum
    });
  }

  useEffect(() => {
    if (route.params?.post) {
      setCounter(route.params?.post);
    }
    else if (route.params?.post == 0) {
      setCounter(0);
    }
  }, [route.params?.post]);

  useEffect(() => {
    if (route.params?.postnum) {
      //uuuu( );
    }
  }, [route.params?.postnum]);



  useEffect(() => {
    if (route.params?.ele) {
      setEleMoney(route.params?.ele);
    }
  }, [route.params?.ele]);

  useEffect(() => {
    if (route.params?.gir) {
      setGirMoney(route.params?.gir);
    }
  }, [route.params?.gir]);

  useEffect(() => {
    if (route.params?.mon) {
      setMonMoney(route.params?.mon);
    }
  }, [route.params?.mon]);

  useEffect(() => {
    if (route.params?.pen) {
      setPenMoney(route.params?.pen);
    }
  }, [route.params?.pen]);

  useEffect(() => {
    if (route.params?.lion) {
      setLionMoney(route.params?.lion);
    }
  }, [route.params?.lion]);



  const [visible, setVisible] = useState('');  //동물 샀는지 안샀는지
  const [Money, setCounter] = useState(0);     //돈 증가 감소



  const [eleMoney, setEleMoney] = useState(100);     //코끼리 구매 비용
  const [girMoney, setGirMoney] = useState(200);     //기린 구매 비용
  const [monMoney, setMonMoney] = useState(300);     //원숭이 구매 비용
  const [penMoney, setPenMoney] = useState(400);     //펭귄 구매 비용




  const ele = () => {
    if (Money >= eleMoney) {
      setVisible('ele'); //도감
      setCounter(Money - eleMoney); //돈측정
      setEleMoney(eleMoney + 20); //구입비용 늘리기 
    }
  }

  const gir = () => {
    if (Money >= girMoney) {
      setVisible('gir');
      setCounter(Money - girMoney);
      setGirMoney(girMoney + 40);
    }
  }

  const mon = () => {
    if (Money >= monMoney) {
      setVisible('mon');
      setCounter(Money - monMoney);
      setMonMoney(monMoney + 60);
    }
  }

  const pen = () => {
    if (Money >= penMoney) {
      setVisible('pen'); //도감
      setCounter(Money - penMoney); //돈측정
      setPenMoney(penMoney + 80); //구입비용 늘리기 
    }
  }




  //뽑기관련
  const [tigerBool, setTigerBool] = useState(false); //호랑이 뽑기로 나온지 체크
  const [tigerNum, setTigerNum] = useState(0); //호랑이 뽑은 수 체크
  const [tigMoney, setTigMoney] = useState(400);     //호랑이 구매 비용
  const [tigImage, setTigImage] = useState(require('./assets/lock.png')); //호랑이 이미지

  const [lionBool, setLionBool] = useState(false); //사자 뽑기로 나온지 체크
  const [lionNum, setLionNum] = useState(0); //사자 뽑은 수 체크
  const [lionMoney, setLionMoney] = useState(600);     //사자 구매 비용
  const [lionImage, setLionImage] = useState(require('./assets/lock.png')); //사자 이미지

  const [dragonBool, setDragonBool] = useState(false); //용 뽑기로 나온지 체크
  const [dragonNum, setDragonNum] = useState(0); //용 뽑은 수 체크
  const [dragonMoney, setDragonMoney] = useState(800);     //용 구매 비용
  const [dragonImage, setDragonImage] = useState(require('./assets/lock.png')); //용 이미지

  const [chameleonBool, setChameleonBool] = useState(false); //카멜레온 뽑기로 나온지 체크
  const [chameleonNum, setChameleonNum] = useState(0); //카멜레온 뽑은 수 체크
  const [chameleonMoney, setChameleonMoney] = useState(1000);     //카멜레온 구매 비용
  const [chameleonImage, setChameleonImage] = useState(require('./assets/lock.png')); //카멜레온 이미지

  const [sunfishBool, setSunfishBool] = useState(false); //개복치 뽑기로 나온지 체크
  const [sunfishNum, setSunfishNum] = useState(0); //개복치 뽑은 수 체크
  const [sunfishMoney, setSunfishMoney] = useState(2000);     //개복치 구매 비용
  const [sunfishImage, setSunfishImage] = useState(require('./assets/lock.png')); //개복치 이미지



  //호랑이
  useEffect(() => {
    if (route.params?.tigNum) {
      setTigerNum(route.params?.tigNum);
      console.log(route.params?.tigNum);
      setTigMoney(400 + route.params?.tigNum * 200);
    }
  }, [route.params?.tigNum]);
  useEffect(() => {
    if (route.params?.tigBool) {
      setTigerBool(route.params?.tigBool);

      if (route.params?.tigBool == true) {
        setTigImage(require('./assets/tiger.png'));
      }
    }
  }, [route.params?.tigBool]);

  //사자
  useEffect(() => {
    if (route.params?.lionNum) {
      setLionNum(route.params?.lionNum);
      console.log(route.params?.lionNum);
      setLionMoney(600 + route.params?.lionNum * 200);
    }
  }, [route.params?.lionNum]);
  useEffect(() => {
    if (route.params?.lionBool) {
      setLionBool(route.params?.lionBool);

      if (route.params?.lionBool == true) {
        setLionImage(require('./assets/lion.png'));
      }
    }
  }, [route.params?.lionBool]);

  //용
  useEffect(() => {
    if (route.params?.dragonNum) {
      setDragonNum(route.params?.dragonNum);
      console.log(route.params?.dragonNum);
      setDragonMoney(800 + route.params?.dragonNum * 200);
    }
  }, [route.params?.dragonNum]);
  useEffect(() => {
    if (route.params?.dragonBool) {
      setDragonBool(route.params?.dragonBool);

      if (route.params?.dragonBool == true) {
        setDragonImage(require('./assets/dragon.png'));
      }
    }
  }, [route.params?.dragonBool]);

  //카멜레온
  useEffect(() => {
    if (route.params?.chameleonNum) {
      setChameleonNum(route.params?.chameleonNum);
      console.log(route.params?.chameleonNum);
      setChameleonMoney(1000 + route.params?.chameleonNum * 200);
    }
  }, [route.params?.dragonNum]);
  useEffect(() => {
    if (route.params?.chameleonBool) {
      setChameleonBool(route.params?.chameleonBool);

      if (route.params?.chameleonBool == true) {
        setChameleonImage(require('./assets/chameleon.png'));
      }
    }
  }, [route.params?.chameleonBool]);

  //개복치
  useEffect(() => {
    if (route.params?.sunfishNum) {
      setSunfishNum(route.params?.sunfishNum);
      console.log(route.params?.sunfishNum);
      setSunfishMoney(2000 + route.params?.sunfishNum * 200);
    }
  }, [route.params?.dragonNum]);
  useEffect(() => {
    if (route.params?.sunfishBool) {
      setSunfishBool(route.params?.sunfishBool);

      if (route.params?.sunfishBool == true) {
        setSunfishImage(require('./assets/sunfish.png'));
      }
    }
  }, [route.params?.sunfishBool]);


  //호랑이 구매?
  const tig = () => {
    if (tigImage != require('./assets/lock.png')) {
      if (Money >= tigMoney) {
        //setVisible('tig'); //도감?
        setCounter(Money - tigMoney);
        setTigerNum(tigerNum + 1);
        setTigMoney(400 + 200 * tigerNum + 200);
      }
    }
  }
  //사자
  const lion = () => {
    if (lionImage != require('./assets/lock.png')) {
      if (Money >= lionMoney) {
        //setVisible('tig'); //도감?
        setCounter(Money - lionMoney);
        setLionNum(lionNum + 1);
        setLionMoney(600 + 200 * lionNum + 200);
      }
    }
  }
  //용
  const dragon = () => {
    if (dragonImage != require('./assets/lock.png')) {
      if (Money >= dragonMoney) {
        //setVisible('tig'); //도감?
        setCounter(Money - dragonMoney);
        setDragonNum(dragonNum + 1);
        setDragonMoney(800 + 200 * dragonNum + 200);
      }
    }
  }
  //카멜레온
  const chameleon = () => {
    if (chameleonImage != require('./assets/lock.png')) {
      if (Money >= chameleonMoney) {
        //setVisible('tig'); //도감?
        setCounter(Money - chameleonMoney);
        setChameleonNum(chameleonNum + 1);
        setChameleonMoney(1000 + 200 * chameleonNum + 200);
      }
    }
  }
  //개복치
  const sunfish = () => {
    if (sunfishImage != require('./assets/lock.png')) {
      if (Money >= sunfishMoney) {
        //setVisible('tig'); //도감?
        setCounter(Money - sunfishMoney);
        setSunfishNum(sunfishNum + 1);
        setSunfishMoney(2000 + 200 * sunfishNum + 200);
      }
    }
  }




  return (
    <View style={{ flex: 1 }}>
      <StatusBar hidden={true} />

      <View style={{ backgroundColor: 'black', flexDirection: 'row', flex: 0.55 }}>
        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 2, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <Image
            style={{ height: 50, width: 50, resizeMode: 'contain' }}
            source={require('./assets/Title_Image.png')} />
        </View>

        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 5, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <Text style={{ fontSize: 35 }} >동물</Text>
        </View>
        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 1, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <TouchableOpacity onPress={moveToMain}>
            <Image style={{ height: 40, width: 40, resizeMode: 'contain' }} source={require('./assets/cancel.png')} />
          </TouchableOpacity>
        </View>
      </View>

      <View style={{ flex: 6 }}>
        <ScrollView>
          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //코끼리
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/elephant.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>코끼리</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{eleMoney}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={ele}> {eleMoney == 100 ? '구입' : '업그레이드'}
                  </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //기린
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/giraffe.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>기린</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{girMoney}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={gir}> {girMoney == 200 ? '구입' : '업그레이드'}
                  </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //원숭이
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/monkey.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>원숭이</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{monMoney}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={mon}> {monMoney == 300 ? '구입' : '업그레이드'}
                  </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //펭귄
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/penguin.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>펭귄</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{penMoney}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={pen}> {penMoney == 400 ? '구입' : '업그레이드'}
                  </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //호랑이
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={tigImage} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>호랑이</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{tigerNum ? tigMoney : "-"}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={tig}> {tigerNum ? '업그레이드' : '-'}
                  </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //사자
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={lionImage} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>사자</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{lionNum ? lionMoney : "-"}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={lion}> {lionNum ? '업그레이드' : '-'}
                  </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //용
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={dragonImage} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>용</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{dragonNum ? dragonMoney : "-"}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={dragon}> {dragonNum ? '업그레이드' : '-'}
                  </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //카멜레온
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={chameleonImage} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>카멜레온</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{chameleonNum ? chameleonMoney : "-"}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={chameleon}> {chameleonNum ? '업그레이드' : '-'}
                  </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //개복치
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={sunfishImage} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>개복치</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{sunfishNum ? sunfishMoney : "-"}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={sunfish}> {sunfishNum ? '업그레이드' : '-'}
                  </Button>
                </View>
              </View>
            </View>
          </View>
        </ScrollView>
      </View>

      <View style={{ flex: 0.5, backgroundColor: '#FBFFB9', flexDirection: 'row', justifyContent: 'center' }}>
        <View style={{ backgroundColor: 'black', flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <View style={{ backgroundColor: '#FBFFB9', width: 100, alignItems: 'center' }}>
            <Image style={{ height: 40, width: 40, resizeMode: 'contain', }} source={require('./assets/dollar.png')} />
          </View>
        </View>
        <View style={{ alignItems: 'center', backgroundColor: 'black', flex: 3 }}>
          <View style={{ backgroundColor: '#FBFFB9', height: 40, width: 300, margin: 3, justifyContent: 'center', alignItems: 'flex-end' }}>
            <Text style={{ fontSize: 25 }}>{Money}</Text>
          </View>
        </View>
      </View>

    </View>
  );
}

function StoreScreen({ navigation , route}) { //상점 씬
  
  const moveToMain = () => {
    navigation.navigate("Main", {storemoney: Money,
                                 buyBool: buyBool,                     
    });
  }

  useEffect(() => {
    if (route.params?.post) {
      setCounter(route.params?.post);
    }

  }, [route.params?.post]);

  useEffect(() => {
    if (route.params?.buyBool) {
     setBuyBool(route.params?.buyBool);
    }
  }, [route.params?.buyBool]);



  const [Money, setCounter] = useState(0);

  const [buyBool, setBuyBool]  = useState(0); //구매했는지 판단.

  
  const buy1 = () => {
    if (Money >= 10000) {
      if (buyBool == 0) {
        setBuyBool(1);
        console.log(buyBool);
        setCounter(Money-10000);
      }
    }
  }

  const buy2 = () => {
    if (Money >= 30000) {
      if (buyBool == 1) {
        setBuyBool(2);
        console.log(buyBool);
        setCounter(Money-30000);
      }
    }
  }

  const buy3 = () => {
    if (Money >= 50000) {
      if (buyBool == 2) {
        setBuyBool(3);
        console.log(buyBool);
        setCounter(Money-50000);
      }
    }
  }

  const buy4 = () => {
    if (Money >= 80000) {
      if (buyBool == 3) {
        setBuyBool(4);
        console.log(buyBool);
        setCounter(Money-80000);
      }
    }
  }

  const buy5 = () => {
    if (Money >= 120000) {
      if (buyBool == 4) {
        setBuyBool(5);
        console.log(buyBool);
        setCounter(Money-150000);
      }
    }
  }

  const buy6 = () => {
    if (Money >= 200000) {
      if (buyBool == 5) {
        setBuyBool(6);
        console.log(buyBool);
        setCounter(Money-200000);
      }
    }
  }






  return (
    <View style={{ flex: 1 }}>
      <View style={{ backgroundColor: 'black', flexDirection: 'row', flex: 0.55 }}>
        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 2, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <Image
            style={{ height: 50, width: 50, resizeMode: 'contain' }}
            source={require('./assets/Title_Image.png')} />
        </View>

        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 5, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <Text style={{ fontSize: 35 }} >편의시설</Text>
        </View>
        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 1, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <TouchableOpacity onPress={moveToMain}>
            <Image style={{ height: 40, width: 40, resizeMode: 'contain' }} source={require('./assets/cancel.png')} />
          </TouchableOpacity>
        </View>
      </View>

      <View style={{ flex: 6 }}>
        <StatusBar hidden={true} />
        <ScrollView>
          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //음료수
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/drink.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>음료수가게</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{buyBool > 0 ? '-' : '10000'}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 16 }} onPress={buy1}> {buyBool > 0 ? '구입완료' : '구입'}
                  </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //츄러스
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/churros.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>츄러스가게</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{buyBool > 1 ? '-' : '30000'}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 16 }} onPress={buy2}> {buyBool > 1 ? '구입완료' : '구입'}
                </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //풍선
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/balloon.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>풍선가게</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{buyBool > 2 ? '-' : '50000'}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 16 }} onPress={buy3}> {buyBool > 2 ? '구입완료' : '구입'}
                </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //팝콘
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/popcorn.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>팝콘가게</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{buyBool > 3 ? '-' : '80000'}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 16 }} onPress={buy4}> {buyBool > 3 ? '구입완료' : '구입'}
                </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image //인형가게
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/teddybear.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>인형가게</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{buyBool > 4 ? '-' : '120000'}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button  mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 16 }} onPress={buy5}> {buyBool > 4 ? '구입완료' : '구입'}
                </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image //레스토랑
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/restaurant.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>레스토랑</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{buyBool > 5 ? '-' : '200000'}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 16 }} onPress={buy6}> {buyBool > 5 ? '구입완료' : '구입'}
                </Button>
                </View>
              </View>
            </View>
          </View>

        </ScrollView>
      </View>
      <View style={{ flex: 0.5, backgroundColor: '#FBFFB9', flexDirection: 'row', justifyContent: 'center' }}>
        <View style={{ backgroundColor: 'black', flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <View style={{ backgroundColor: '#FBFFB9', width: 100, alignItems: 'center' }}>
            <Image style={{ height: 40, width: 40, resizeMode: 'contain', }} source={require('./assets/dollar.png')} />
          </View>
        </View>
        <View style={{ alignItems: 'center', backgroundColor: 'black', flex: 3 }}>
          <View style={{ backgroundColor: '#FBFFB9', height: 40, width: 300, margin: 3, justifyContent: 'center', alignItems: 'flex-end' }}>
            <Text style={{ fontSize: 25 }}>{Money}</Text>
          </View>
        </View>
      </View>

    </View>
  );
}

function ZooKeeperScreen({ navigation, route }) { //직원 탭

  const moveToMain = () => {
    navigation.navigate("Main", {ManMoney : Money, 
                                 eleMan : eleMan, eleManMoney: eleManMoney,
                                 girMan : girMan, girManMoney: girManMoney,
                                 monMan : monMan, monManMoney: monManMoney,
                                 penMan : penMan, penManMoney: penManMoney,
                                 tigerMan : tigerMan, tigerManMoney : tigerManMoney,
                                 lionMan : lionMan, lionManMoney : lionManMoney,
                                 dragonMan : dragonMan, dragonManMoney: dragonManMoney,
                                 chameleonMan : chameleonMan, chameleonManMoney : chameleonManMoney,
                                 sunfishMan : sunfishMan, sunfishManMoney: sunfishManMoney
                                }); 
  }

  

  useEffect(() => {
    //코끼리
    if (route.params?.eleMan) {
      setEleMan(route.params?.eleMan);
    }
    if (route.params?.eleManMoney) {
      setEleManMoney(route.params?.eleManMoney);
    }
    //기린
    if (route.params?.girMan) {
      setGirMan(route.params?.girMan);
    }
    if (route.params?.girManMoney) {
      setGirManMoney(route.params?.girManMoney);
    }
    //원숭이
    if (route.params?.monMan) {
      setGirMan(route.params?.monMan);
    }
    if (route.params?.monManMoney) {
      setMonManMoney(route.params?.monManMoney);
    }
    //펭귄
    if (route.params?.penMan) {
      setGirMan(route.params?.penMan);
    }
    if (route.params?.penManMoney) {
      setPenManMoney(route.params?.penManMoney);
    }
    //호랑이
    if (route.params?.tigerMan) {
      setGirMan(route.params?.tigerMan);
    }
    if (route.params?.tigerManMoney) {
      setTigerManMoney(route.params?.tigerManMoney);
    }
    //사자
    if (route.params?.lionMan) {
      setGirMan(route.params?.lionMan);
    }
    if (route.params?.lionManMoney) {
      setLionManMoney(route.params?.lionManMoney);
    }
    //드래곤
    if (route.params?.dragonMan) {
      setGirMan(route.params?.dragonMan);
    }
    if (route.params?.dragonManMoney) {
      setDragonManMoney(route.params?.dragonManMoney);
    }
    //카멜레온
    if (route.params?.chameleonMan) {
      setGirMan(route.params?.chameleonMan);
    }
    if (route.params?.chameleonManMoney) {
      setChameleonManMoney(route.params?.chameleonManMoney);
    }
    //개복치
    if (route.params?.sunfishMan) {
      setGirMan(route.params?.sunfishMan);
    }
    if (route.params?.sunfishManMoney) {
      setSunfishManMoney(route.params?.sunfishManMoney);
    }

  }, [route.params?.eleMan, route.params?.eleManMoney,
      route.params?.girMan, route.params?.girManMoney,
      route.params?.monMan, route.params?.monManMoney,
      route.params?.penMan, route.params?.penManMoney,
      route.params?.tigerMan, route.params?.tigerManMoney,
      route.params?.lionMan, route.params?.lionManMoney,
      route.params?.dragonMan, route.params?.dragonManMoney,
      route.params?.chameleonMan, route.params?.chameleonManMoney,
      route.params?.sunfishMan, route.params?.sunfishManMoney,
    ]);




  const [eleMan, setEleMan] = useState(0); // 직원 코끼리 수.
  const [girMan, setGirMan] = useState(0); // 직원 기린 수.
  const [monMan, setMonMan] = useState(0); // 직원 원숭이 수
  const [penMan, setPenMan] = useState(0); // 직원 펭귄 수
  const [tigerMan, setTigerMan] = useState(0); // 직원 호랑이 수
  const [lionMan, setLionMan] = useState(0); //직원 사자 수
  const [dragonMan, setDragonMan] = useState(0); //직원 드래곤 수
  const [chameleonMan, setChameleonMan] = useState(0); // 직원 카멜레온 수
  const [sunfishMan, setSunfishMan] = useState(0); // 직원 개복치 수




  const [eleManMoney, setEleManMoney] = useState(1000);
  const [girManMoney, setGirManMoney] = useState(3000);
  const [monManMoney, setMonManMoney] = useState(5000);
  const [penManMoney, setPenManMoney] = useState(8000);
  const [tigerManMoney, setTigerManMoney] = useState(10000);
  const [lionManMoney, setLionManMoney] = useState(15000);
  const [dragonManMoney, setDragonManMoney] = useState(20000);
  const [chameleonManMoney, setChameleonManMoney] = useState(35000);
  const [sunfishManMoney, setSunfishManMoney] = useState(50000);



  const buyEleMan = () => {
    if (Money >= eleManMoney && BuyZoo >= 0) {
      setEleMan(eleMan + 1);
      setCounter(Money - eleManMoney);
      setEleManMoney(eleManMoney + 1000);
      BuyEleNum++;
      if(BuyZoo == 0)
      {
        BuyZoo = 1;
      }
    }
  }

  const buyGirMan = () => {
    if (Money >= girManMoney && BuyZoo >= 1) {
      setGirMan(girMan + 1);
      setCounter(Money - girManMoney);
      setGirManMoney(girManMoney + 3000);
      BuyGirNum++;
      if(BuyZoo == 1)
      {
        BuyZoo = 2;
      }
    }
  }

  const buyMonMan = () => {
    if (Money >= monManMoney && BuyZoo >= 2) {
      setMonMan(monMan + 1);
      setCounter(Money - monManMoney);
      setMonManMoney(monManMoney + 5000);
      BuyMonNum++;
      if(BuyZoo == 2)
      {
        BuyZoo = 3;
      }
    }
  }

  const buyPenMan = () => {
    if (Money >= penManMoney && BuyZoo >= 3) {
      setPenMan(penMan + 1);
      setCounter(Money - penManMoney);
      setPenManMoney(penManMoney + 8000);
      BuyPenNum++;
      if(BuyZoo == 3)
      {
        BuyZoo = 4;
      }
    }
  }

  const buyTigerMan = () => {
    if (Money >= tigerManMoney && BuyZoo >= 4) {
      setTigerMan(tigerMan + 1);
      setCounter(Money - tigerManMoney);
      setTigerManMoney(tigerManMoney + 10000);
      BuyTigerNum++;
      if(BuyZoo == 4)
      {
        BuyZoo = 5;
      }
    }
  }
  const buyLionMan = () => {
    if (Money >= lionManMoney && BuyZoo >= 5) {
      setLionMan(lionMan + 1);
      setCounter(Money - lionManMoney);
      setLionManMoney(lionManMoney + 15000);
      BuyLionNum++;
      if(BuyZoo == 5)
      {
        BuyZoo = 6;
      }
    }
  }
  const buyDragonMan = () => {
    if (Money >= dragonManMoney && BuyZoo >= 6) {
      setDragonMan(dragonMan + 1);
      setCounter(Money - dragonManMoney);
      setDragonManMoney(dragonManMoney + 20000);
      BuyDragonNum++;
      if(BuyZoo == 6)
      {
        BuyZoo = 7;
      }
    }
  }
  const buyChameleonMan = () => {
    if (Money >= chameleonManMoney && BuyZoo >= 7) {
      setChameleonMan(chameleonMan + 1);
      setCounter(Money - chameleonManMoney);
      setChameleonManMoney(chameleonManMoney + 35000);
      BuyChameleonNum++;
      if(BuyZoo == 7)
      {
        BuyZoo = 8;
      }
    }
  }
  const buySunfishMan = () => {
    if (Money >= sunfishManMoney && BuyZoo >= 8) {
      setSunfishMan(sunfishMan + 1);
      setCounter(Money - sunfishManMoney);
      setSunfishManMoney(sunfishManMoney + 50000);
      BuySunfishNum++;
      if(BuyZoo == 8)
      {
        BuyZoo = 9;
      }
    }
  }


  const [Money, setCounter] = useState(0);     //돈 증가 감소
  useEffect(() => {
    if (route.params?.post) {
      setCounter(route.params?.post);
    }
  }, [route.params?.post]);


  return (
    <View style={{ flex: 1 }}>
      <View style={{ backgroundColor: 'black', flexDirection: 'row', flex: 0.55 }}>
        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 2, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <Image
            style={{ height: 50, width: 50, resizeMode: 'contain' }}
            source={require('./assets/Title_Image.png')} />
        </View>

        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 5, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <Text style={{ fontSize: 35 }} >직원</Text>
        </View>
        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 1, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <TouchableOpacity onPress={moveToMain}>
            <Image style={{ height: 40, width: 40, resizeMode: 'contain' }} source={require('./assets/cancel.png')} />
          </TouchableOpacity>
        </View>
      </View>

      <View style={{ flex: 6 }}>
        <StatusBar hidden={true} />
        <ScrollView>
          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/elephant.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>코끼리 사육사</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{BuyZoo >= 0 ? eleManMoney : "-"}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button  mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress ={buyEleMan} > {eleManMoney > 1000 ? "업그레이드" : "구입"}
                </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //코끼리
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/giraffe.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>기린 사육사</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{BuyZoo >= 1 ? girManMoney : "-"}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button  mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress ={buyGirMan}> {girManMoney > 3000 ? "업그레이드" : "구입"}
                </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //코끼리
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/monkey.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>원숭이 사육사</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{BuyZoo >= 2 ? monManMoney : "-"}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={buyMonMan}> {monManMoney > 5000 ? "업그레이드" : "구입"}
                </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //코끼리
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/penguin.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>펭귄 사육사</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{BuyZoo >= 3 ? penManMoney : "-"}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={buyPenMan}> {penManMoney > 8000 ? "업그레이드" : "구입"}
                </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/tiger.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>호랑이 사육사</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{BuyZoo >= 4 ? tigerManMoney : "-"}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={buyTigerMan}> {tigerManMoney > 10000 ? "업그레이드" : "구입"}
                </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/lion.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>사자 사육사</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{BuyZoo >= 5 ? lionManMoney : "-"}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={buyLionMan}> {lionManMoney > 15000 ? "업그레이드" : "구입"}
                </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/dragon.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>용 사육사</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{BuyZoo >= 6 ? dragonManMoney : "-"}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={buyDragonMan}> {dragonManMoney > 20000 ? "업그레이드" : "구입"}
                </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/chameleon.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>카멜레온 사육사</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{BuyZoo >= 7 ? chameleonManMoney : "-"}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={buyChameleonMan}> {chameleonManMoney > 35000 ? "업그레이드" : "구입"}
                </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/sunfish.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>개복치 사육사</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{BuyZoo >= 8 ? sunfishManMoney : "-"}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 15 }} onPress={buySunfishMan}> {sunfishManMoney > 50000 ? "업그레이드" : "구입"}
                </Button>
                </View>
              </View>
            </View>
          </View>
        </ScrollView>
      </View>

      <View style={{ flex: 0.5, backgroundColor: '#FBFFB9', flexDirection: 'row', justifyContent: 'center' }}>
        <View style={{ backgroundColor: 'black', flex: 1, justifyContent: 'center', alignItems: 'center' }}>
          <View style={{ backgroundColor: '#FBFFB9', width: 100, alignItems: 'center' }}>
            <Image style={{ height: 40, width: 40, resizeMode: 'contain', }} source={require('./assets/dollar.png')} />
          </View>
        </View>
        <View style={{ alignItems: 'center', backgroundColor: 'black', flex: 3 }}>
          <View style={{ backgroundColor: '#FBFFB9', height: 40, width: 300, margin: 3, justifyContent: 'center', alignItems: 'flex-end' }}>
            <Text style={{ fontSize: 25 }}>{Money}</Text>
          </View>
        </View>
      </View>

    </View>
  );
}

let RouletteCount = 0; //룰렛 뽑은 수

function RouletteScreen({ navigation, route }) { //뽑기

  const [Money, setCounter] = useState(0);     //돈 증가 감소
  const [Name, setName] = useState("");
  const [image, imageC] = useState(require('./assets/Egg.png')); //뽑기창 중간 이미지.

  const decreaseCounter = () => {

    if (Money >= 100) {

      setRmodal(true); //룰렛 모달창 띄우기
      //press();

      let prob = Random.getRandomBytes(1) % 100;

      setCounter(Money - 100);
      //개복치
      if (prob <= 20) {
        imageC(require('./assets/sunfish.png'));
        x.value = repeat(withTiming((x.value - 1600), { duration: 600, easing: Easing.linear }), 4, false,
          (finished) => { x.value = (finished) ? x.value + 1495 : x.value; });
        //이미지 바꾸는 코드
        RouletteCount++;
        setSunfishBool(true);
        setSunfishNum(sunfishNum + 1);
      }
      //카멜레온
      else if (prob > 20 && prob <= 40) {
        imageC(require('./assets/chameleon.png'));

        x.value = repeat(withTiming((x.value - 1600), { duration: 600, easing: Easing.linear }), 4, false,
          (finished) => { x.value = (finished) ? x.value + 1292 : x.value; });
        //이미지 바꾸는 코드
        RouletteCount++;
        setChameleonBool(true);
        setChameleonNum(chameleonNum + 1);
      }
      //용
      else if (prob > 40 && prob <= 60) {
        imageC(require('./assets/dragon.png'));

        x.value = repeat(withTiming((x.value - 1600), { duration: 600, easing: Easing.linear }), 4, false,
          (finished) => { x.value = (finished) ? x.value + 888 : x.value; });
        //이미지 바꾸는 코드
        RouletteCount++;
        setDragonBool(true);
        setDragonNum(dragonNum + 1);
      }
      //사자
      else if (prob > 60 && prob <= 80) {
        imageC(require('./assets/lion.png'));

        x.value = repeat(withTiming((x.value - 1600), { duration: 600, easing: Easing.linear }), 4, false,
          (finished) => { x.value = (finished) ? x.value + 483 : x.value; });
        //이미지 바꾸는 코드
        RouletteCount++;
        setLoinBool(true);
        setLionNum(lionNum + 1);
      }
      //호랑이
      else {
        imageC(require('./assets/tiger.png'));

        x.value = repeat(withTiming((x.value - 1600), { duration: 600, easing: Easing.linear }), 4, false,
          (finished) => { x.value = (finished) ? x.value + 1090 : x.value; });

        RouletteCount++;
        setTigerBool(true);
        setTigerNum(tigerNum + 1);

        console.log("------------------------------------");
        console.log(tigerNum);
        console.log(tigerBool);
        //이미지 바꾸는 코드
      }
    }


  }
  const moveToMain = () => {
    navigation.navigate("Main", {
      post: Money,
      tigBool: tigerBool, tigNum: tigerNum,
      lionBool: lionBool, lionNum: lionNum,
      dragonBool: dragonBool, dragonNum: dragonNum,
      chameleonBool: chameleonBool, chameleonNum: chameleonNum,
      sunfishBool: sunfishBool, sunfishNum: sunfishNum
    });
  }
  //돈
  useEffect(() => {
    if (route.params?.post) {
      setCounter(route.params?.post);
    }
  }, [route.params?.post]);

  const [tigerBool, setTigerBool] = useState(false); //호랑이 뽑기로 나온지 체크
  const [lionBool, setLoinBool] = useState(false); //사자 뽑기로 나온지 체크
  const [dragonBool, setDragonBool] = useState(false); //용 뽑기로 나온지 체크
  const [chameleonBool, setChameleonBool] = useState(false); //카멜레온 뽑기로 나온지 체크
  const [sunfishBool, setSunfishBool] = useState(false); //개복치 뽑기로 나온지 체크

  const [tigerNum, setTigerNum] = useState(0); //호랑이 뽑은 수 체크
  const [lionNum, setLionNum] = useState(0); //사자 뽑은 수 체크
  const [dragonNum, setDragonNum] = useState(0); //용 뽑은 수 체크
  const [chameleonNum, setChameleonNum] = useState(0); //카멜레온 뽑은 수 체크
  const [sunfishNum, setSunfishNum] = useState(0); //개복치 뽑은 수 체크

  //호랑이
  useEffect(() => {
    if (route.params?.tigBool) {
      setTigerBool(route.params?.tigBool);
    }
    else {
      setTigerBool(false);
    }
  }, [route.params?.tigBool]);
  useEffect(() => {
    if (route.params?.tigNum) {
      setTigerNum(route.params?.tigNum);
    }

  }, [route.params?.tigNum]);

  //사자
  useEffect(() => {
    if (route.params?.lionBool) {
      setLoinBool(route.params?.lionBool);
    }
    else {
      setLoinBool(false);
    }
  }, [route.params?.lionBool]);
  useEffect(() => {
    if (route.params?.lionNum) {
      setLionNum(route.params?.lionNum);
    }

  }, [route.params?.lionNum]);

  //용
  useEffect(() => {
    if (route.params?.dragonBool) {
      setDragonBool(route.params?.dragonBool);
    }
    else {
      setDragonBool(false);
    }
  }, [route.params?.dragonBool]);
  useEffect(() => {
    if (route.params?.dragonNum) {
      setDragonNum(route.params?.dragonNum);
    }

  }, [route.params?.dragonNum]);

  //카멜레온
  useEffect(() => {
    if (route.params?.chameleonBool) {
      setChameleonBool(route.params?.chameleonBool);
    }
    else {
      setChameleonBool(false);
    }
  }, [route.params?.chameleonBool]);
  useEffect(() => {
    if (route.params?.chameleonNum) {
      setChameleonNum(route.params?.chameleonNum);
    }

  }, [route.params?.chameleonNum]);

  //개복치
  useEffect(() => {
    if (route.params?.sunfishBool) {
      setSunfishBool(route.params?.sunfishBool);
    }
    else {
      setSunfishBool(false);
    }
  }, [route.params?.sunfishBool]);
  useEffect(() => {
    if (route.params?.sunfishNum) {
      setSunfishNum(route.params?.sunfishNum);
    }

  }, [route.params?.sunfishNum]);


  //probability


  //--------------------------------------------------------------------------------
  //룰렛기능
  const [Rmodal, setRmodal] = useState(false); //룰렛 돌아가는 거 보여주는 모달설정
  const [probability, setProbability] = useState(false); //확률 몇퍼인지 보여주는 모달설정


  const CloseRModal = () => {
    setRmodal(false);
    s();
  }

  const CloseProbModal = () => {
    setProbability(false);
  }



  const AnimatedImageBackground = Animated.createAnimatedComponent(ImageBackground);
  const x = useSharedValue(0);
  const y = useSharedValue(0);
  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [
        { translateX: x.value + 1500 }, //66
        { translateY: -20 },
        { scale: 3 },
      ]
    }
  });
  const press = () => {

    //x.value = 0;
    x.value = repeat(withTiming((x.value - 300), { duration: 200, easing: Easing.linear }), -1, false);
    //y.value = repeat(withTiming((y.value+227), {duration: 200, easing: Easing.linear}), -1, false);
  }
  const stop = () => {
    cancelAnimation(x);
  }
  const s = () => {

    x.value = 0;
  }
  let background = <AnimatedImageBackground imageStyle={{ resizeMode: 'repeat', overflow: 'hidden' }}
    style={[{ alignSelf: 'flex-start', width: 1600, height: 1600 }, animatedStyle]}
    source={require('./assets/ROU.png')}
  />;

  //--------------------------------------------------------------------------------


  return (
    <View style={{ flex: 1 }}>
      <StatusBar hidden={true} />

      <Modal
        animationType="fade"
        transparent={true}
        visible={Rmodal}
        onRequestClose={() => {
          Alert.alert('Modal has been closed.');
        }}>

        <View style={styles.centeredView}>
          <View style={styles.RoulletView}>
            <View style={{ backgroundColor: "#755744" }}>
              <View style={[{ width: 200, height: 200, overflow: 'hidden', backgroundColor: '#FBFFB9', margin: 10 }]}>
                {background}
              </View>
            </View>
            <View>
              <Text style={{ fontSize: 40 }}> {Name} </Text>
            </View>
            <View style={{ top: 50 }}>
              <Button mode="contained" compact="true" color="#755744" contentStyle={{ height: 40, width: 150 }}
                labelStyle={{ color: "white", fontSize: 30 }} onPress={CloseRModal} >확인</Button>
            </View>
          </View>
        </View>
      </Modal>


      <Modal
        animationType="fade"
        transparent={true}
        visible={probability}
        onRequestClose={() => {
          Alert.alert('확률창임.');
        }}>
        <View style={styles.centeredView}>
          <View style={styles.ProbView}>
            <View style={{ backgroundColor: "#755744", flex: 1 }}>
              <View style={{ flex: 1, margin: 5, backgroundColor: '#FBFFB9' }}>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                  <View style={{ flex: 1, alignItems: 'center', backgroundColor: '#755744', margin: 5 }}>
                    <Image
                      style={{ height: 60, width: 60, resizeMode: 'contain' }}
                      source={require('./assets/tiger.png')} />
                    <View>
                      <Text style={{ fontSize: 20, left: 5 }}> 20% </Text>
                    </View>
                  </View>
                  <View style={{ flex: 1, alignItems: 'center', backgroundColor: '#755744', margin: 5 }}>
                    <Image
                      style={{ height: 60, width: 60, resizeMode: 'contain' }}
                      source={require('./assets/lion.png')} />
                    <View>
                      <Text style={{ fontSize: 20, left: 5 }}> 20% </Text>
                    </View>
                  </View>
                </View>
              </View>

              <View style={{ flex: 1, margin: 5, backgroundColor: '#FBFFB9' }}>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                  <View style={{ flex: 1, alignItems: 'center', backgroundColor: '#755744', margin: 5 }}>
                    <Image
                      style={{ height: 60, width: 60, resizeMode: 'contain' }}
                      source={require('./assets/sunfish.png')} />
                    <View>
                      <Text style={{ fontSize: 20, left: 5 }}> 20% </Text>
                    </View>
                  </View>
                  <View style={{ flex: 1, alignItems: 'center', backgroundColor: '#755744', margin: 5 }}>
                    <Image
                      style={{ height: 60, width: 60, resizeMode: 'contain' }}
                      source={require('./assets/chameleon.png')} />
                    <View>
                      <Text style={{ fontSize: 20, left: 5 }}> 20% </Text>
                    </View>
                  </View>
                </View>
              </View>

              <View style={{ flex: 1, margin: 5, backgroundColor: '#FBFFB9' }}>
                <View style={{ flex: 1, flexDirection: 'row' }}>
                  <View style={{ flex: 1, alignItems: 'center', backgroundColor: '#755744', margin: 5 }}>
                    <Image
                      style={{ height: 60, width: 60, resizeMode: 'contain' }}
                      source={require('./assets/dragon.png')} />
                    <View>
                      <Text style={{ fontSize: 20, left: 5 }}> 20% </Text>
                    </View>
                  </View>
                  <View style={{ flex: 1, alignItems: 'center', backgroundColor: '#755744', margin: 5 }}>
                    <Image
                      style={{ height: 60, width: 60, resizeMode: 'contain', top: 10 }}
                      source={require('./assets/lock.png')} />
                    <View>
                    </View>
                  </View>
                </View>
              </View>
            </View>
            <View style={{ alignItems: 'center', top: 10 }}>
              <Button mode="contained" compact="true" color="#755744" contentStyle={{ height: 40, width: 100 }}
                labelStyle={{ color: "white", fontSize: 30 }} onPress={() => setProbability(false)}>확인</Button>
            </View>
          </View>
        </View>
      </Modal>




      <View style={{ backgroundColor: 'black', flexDirection: 'row', flex: 1 }}>
        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 2, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <Image
            style={{ height: 50, width: 50, resizeMode: 'contain' }}
            source={require('./assets/Title_Image.png')} />
        </View>

        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 5, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <Text style={{ fontSize: 35 }} >뽑기</Text>
        </View>


        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 1, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <TouchableOpacity onPress={moveToMain}>
            <Image style={{ height: 40, width: 40, resizeMode: 'contain' }} source={require('./assets/cancel.png')} />
          </TouchableOpacity>
        </View>
      </View>

      <View style={{ alignItems: 'center', justifyContent: 'center', flex: 12 }}>
        <View style={{ flex: 1 }}>
          <Text style={{ alignItems: 'center', justifyContent: 'center', fontSize: 30 }}>{Money} </Text>
        </View>
        <View style={{ flex: 8, justifyContent: 'center' }}>
          <Image
            style={{ height: 200, width: 200, resizeMode: 'contain' }}
            source={image} />
        </View>

        <View style={{ flex: 1 }}>
          <Button mode="contained" compact="true" color="#755744" contentStyle={{ height: 40, width: 200 }}
            labelStyle={{ color: "white", fontSize: 30 }} onPress={decreaseCounter} >뽑기
         </Button>
        </View>

        <View style={{ flex: 1 }}>
          <Button mode="contained" compact="true" color="#755744" contentStyle={{ height: 40, width: 200 }}
            labelStyle={{ color: "white", fontSize: 30 }} onPress={() => setProbability(true)} >뽑기 목록
         </Button>
        </View>

      </View>
    </View>
  );

}


let quest1_money = 0; 
let quest2_money = 0;
let quest3_money = 0;
let quest4_money = 0;

function QuestScreen({ navigation, route }) { //업적

  const moveToMain = () => {
    navigation.navigate("Main", { qusetMaingold: qusetMain, MainNum: countMainNum, 
                                  quest2: quest2, quest2Count: quest2Count,
                                  quest3: quest3, quest3Count: quest3Count,
                                  quest4: quest4, quest4Count: quest4Count,
                                  questMoney : Money});
  }

  //돈 
  const [Money, setCounter] = useState(0);  

  // 첫번째 퀘스트
  const [qusetMain, setnumMain] = useState(0);  // 돈 얼마줄건지
  const [countMainNum, setCountMainNum] = useState(10); //100 카운트세는애

  useEffect(() => {
    if (route.params?.qusetMaingold) {
      setnumMain(route.params?.qusetMaingold);
    }
  }, [route.params?.qusetMaingold]);

  useEffect(() => {
    if (route.params?.MainNum) {
      setCountMainNum(route.params?.MainNum);
    }
  }, [route.params?.MainNum]);

  useEffect(() => {
    if (route.params?.countHome) {
      
    }
  }, [route.params?.countHome]);



  //2번째 퀘스트 
  const [quest2, setQuest2] = useState(0); //퀘스트2 보상
  const [quest2Count, setquset2Count] = useState(0); // 퀘스트2 내용

  useEffect(() => {
    if (route.params?.quest2)
    {
      setQuest2(route.params?.quest2);
    }

    if(route.params?.quest2Count)
    {
      setquset2Count(route.params?.quest2Count);
    }

  },[route.params?.quest2,route.params?.quest2Count]);


  //3번째 퀘스트
  const [quest3, setQuest3] = useState(0); //퀘스트3 보상
  const [quest3Count, setquset3Count] = useState(0); // 퀘스트3 내용

  useEffect(() => {
    if (route.params?.quest3)
    {
      setQuest3(route.params?.quest3);
    }

    if(route.params?.quest3Count)
    {
      setquset3Count(route.params?.quest3Count);
    }

  },[route.params?.quest3,route.params?.quest3Count]);

  useEffect(() => {
    if (route.params?.post) {
      setCounter(route.params?.post);
    }
  }, [route.params?.post]);



  //4번째 퀘스트
  const [quest4, setQuest4] = useState(0); //퀘스트4 보상
  const [quest4Count, setquset4Count] = useState(0); // 퀘스트4 내용

  useEffect(() => {
    if (route.params?.quest4)
    {
      setQuest4(route.params?.quest4);
    }

    if(route.params?.quest4Count)
    {
      setquset4Count(route.params?.quest4Count);
    }

  },[route.params?.quest4,route.params?.quest4Count]);




  //획득 누르는 버튼
  const QuestButton_1 = () => {
    if(route.params?.countHome >= countMainNum) {
      setCounter(Money + qusetMain+500);
      setnumMain(qusetMain + 500);
      setCountMainNum(countMainNum + 10);
    }
  }

  const QuestButton_2 = () => {
    if(RouletteCount >= quest2Count) {
      setCounter(Money + quest2+ 1000);
      setQuest2(quest2 + 1000);
      setquset2Count(quest2Count + 10);
    }
  }

  const QuestButton_3 = () => {
    if(route.params?.post >= quest3Count) {
      setCounter(Money + quest3+ 10000);
      setQuest3(quest3 + 10000);
      setquset3Count(quest3Count + 50000);
    }
  }

  const QuestButton_4 = () => {
    if(BuyZoo >= quest4Count) {
      setCounter(Money + quest4+ 5000);
      setQuest4(quest4 + 5000);
      setquset4Count(quest4Count + 1);
    }
  }


  return (
    <View>
      <View style={{ backgroundColor: 'black', flexDirection: 'row' }}>
        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 2, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <Image
            style={{ height: 50, width: 50, resizeMode: 'contain' }}
            source={require('./assets/medal.png')} />
        </View>

        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 5, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <Text style={{ fontSize: 35 }} >업적</Text>
        </View>
        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 1, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <TouchableOpacity onPress={moveToMain}>
            <Image style={{ height: 40, width: 40, resizeMode: 'contain' }} source={require('./assets/cancel.png')} />
          </TouchableOpacity>
        </View>
      </View>

      <View >
        <StatusBar hidden={true} />
        <ScrollView>
          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/medal.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 20 }}>메인 건물 {countMainNum}번 클릭</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{qusetMain+500}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color={route.params?.countHome >= countMainNum ? '#FCFF70' : 'white'} Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 16 }} onPress={QuestButton_1}> {route.params?.countHome >= countMainNum ? '획득' : '획득불가'}
              </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/medal.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 20 }}>뽑기 {quest2Count}번 이상</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{quest2 + 1000}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color={RouletteCount >= quest2Count ? '#FCFF70' : 'white'} Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 16 }} onPress={QuestButton_2}> {RouletteCount >= quest2Count ? '획득' : '획득불가'}
                  </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image 
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/medal.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 20 }}>직원 수 {quest4Count}</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{quest4 + 5000}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color={BuyZoo >= quest4Count ? '#FCFF70' : 'white'} Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 16 }} onPress={QuestButton_4}> {BuyZoo >= quest4Count ? '획득' : '획득불가'}
              </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image  //코끼리
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/medal.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 20 }}>보유한 돈 {quest3Count}</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>{quest3 + 10000}</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color={route.params?.post >= quest3Count ? '#FCFF70' : 'white'} Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 16 }} onPress={QuestButton_3}> {route.params?.post >= quest3Count ? '획득' : '획득불가'}
              </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/lock.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 20 }}>잠김</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>-</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 16 }}> 획득
              </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/lock.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 20 }}>잠김</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>-</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 16 }}> 획득
              </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/lock.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 20 }}>잠김</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>-</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 16 }}> 획득
              </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/lock.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>잠김</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>-</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 16 }}> 획득
              </Button>
                </View>
              </View>
            </View>
          </View>

          <View style={{ backgroundColor: '#CFC810', height: 100 }}>
            <View style={{ backgroundColor: 'black', margin: 5, flex: 1, flexDirection: 'row' }}>
              <View style={{ backgroundColor: '#B46E06', flex: 1, right: 2.5, alignItems: 'center', justifyContent: 'center' }}>
                <Image
                  style={{ height: 80, width: 80, resizeMode: 'contain' }}
                  source={require('./assets/medal.png')} />
              </View>
              <View style={{ backgroundColor: '#B46E06', flex: 3, left: 2.5, flexDirection: 'row' }}>
                <View style={{ backgroundColor: 'gray', flex: 2, }}>
                  <Text style={{ backgroundColor: '#B46E06', height: 45, fontSize: 25 }}>업적 내용</Text>
                  <View style={{ margin: 5, backgroundColor: 'yellow' }}>
                    <Text style={{ backgroundColor: '#B46E06', height: 35, fontSize: 20, }}>돈</Text>
                  </View>
                </View>
                <View style={{ backgroundColor: '#B46E06', flex: 1, justifyContent: 'center', margin: 5 }}>
                  <Button mode="contained" compact="true" color='#FCFF70' Style={{ height: 20, width: 60 }}
                    labelStyle={{ color: "black", fontSize: 16 }}> 획득
              </Button>
                </View>
              </View>
            </View>
          </View>

        </ScrollView>
      </View>
    </View>
  );
}

function AnimalBookScreen({ navigation, route }) { //도감

  const moveToMain = () => {
    navigation.navigate("Main");
  }

  useEffect(() => {
    if (route.params?.ele > 100) {
      Ele();
    }

    if (route.params?.gir > 200)
    {
      Gir();
    }

    if (route.params?.mon > 300)
    {
      Mon();
    }

    if (route.params?.pen > 400)
    {
      Pen();
    }

    if (route.params?.tigNum > 0)
    {
      Tiger();
    }
    if (route.params?.lionNum > 0)
    {
      Lion();
    }
    if (route.params?.dragonNum > 0)
    {
      Dragon();
    }
    if (route.params?.chameleonNum > 0)
    {
      Chameleon();
    }
    if (route.params?.sunfishNum > 0)
    {
      Sunfish();
    }

    
  
  }, [route.params?.ele, route.params?.gir, route.params?.mon, route.params?.pen, 
    route.params?.tigerNum, route.params?.lionNum, route.params?.dragonNum, route.params?.chameleonNum, route.params?.sunfishNum]);



  const [image_e, imageC_E] = useState(require('./assets/lock.png'));
  const [image_g, imageC_G] = useState(require('./assets/lock.png'));
  const [image_m, imageC_M] = useState(require('./assets/lock.png'));
  const [image_p, imageC_P] = useState(require('./assets/lock.png'));
  const [image_t, imageC_T] = useState(require('./assets/lock.png'));
  const [image_l, imageC_L] = useState(require('./assets/lock.png'));
  const [image_d, imageC_D] = useState(require('./assets/lock.png'));
  const [image_c, imageC_C] = useState(require('./assets/lock.png'));
  const [image_s, imageC_S] = useState(require('./assets/lock.png'));




  const Ele = () => {
    imageC_E(require('./assets/elephant.png'));
  }

  const Gir = () => {
    imageC_G(require('./assets/giraffe.png'));
  }

  const Mon = () => {
    imageC_M(require('./assets/monkey.png'));
  }

  const Pen = () => {
    imageC_P(require('./assets/penguin.png'));
  }

  const Tiger = () => {
    imageC_T(require('./assets/tiger.png'));
  }

  const Lion = () => {
    imageC_L(require('./assets/lion.png'));
  }
  
  const Dragon = () => {
    imageC_D(require('./assets/dragon.png'));
  }

  const Chameleon = () => {
    imageC_C(require('./assets/chameleon.png'));
  }

  const Sunfish = () => {
    imageC_S(require('./assets/sunfish.png'));
  }






  return (
    <View style={styles.AppBarStyle}>
      <View style={{ backgroundColor: 'black', flexDirection: 'row' }}>
        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 2, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <Image
            style={{ height: 50, width: 50, resizeMode: 'contain' }}
            source={require('./assets/book.png')} />
        </View>

        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 5, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <Text style={{ fontSize: 35 }} >도감</Text>
        </View>

        <View style={{ backgroundColor: '#FBFFB9', height: 46, flex: 1, alignItems: 'center', justifyContent: 'center', margin: 2 }}>
          <TouchableOpacity onPress={moveToMain}>
            <Image style={{ height: 40, width: 40, resizeMode: 'contain' }} source={require('./assets/cancel.png')} />
          </TouchableOpacity>
        </View>
      </View>




      <ScrollView>
        <View style={{ backgroundColor: '#CFC810', flexDirection: 'row' }}>
          <View style={styles.box}>
            <Image
              style={{ height: 100, width: 100, resizeMode: 'contain' }}
              source={image_e} />
            <Text style={{ fontSize: 20, color: "black", }}> { route.params?.ele > 100 ?"코끼리과 동물. 포유류 기다란 코와 큰 몸이 특징이다. 지상에서 가장 큰 동물. 2t~6t까지 나간다. " : "-"} </Text>
          </View>

          <View style={styles.box}>
            <Image
              style={{ height: 100, width: 100, resizeMode: 'contain' }}
              source={image_g}  />
            <Text style={{ fontSize: 20, color: "black" }}>  { route.params?.gir > 200 ?"기린과의 동물. 몹시 큰 키와 길다란 목으로 유명하다. 성체의 경우 키는 3.5~5m 정도이며 무게는 0.55~1.7t 이며 최대 무게는 2t에 달한다. " : "-"}</Text>
          </View>
        </View>
        <View style={{ backgroundColor: '#CFC810', flexDirection: 'row' }}>
          <View style={styles.box}>
            <Image
              style={{ height: 100, width: 100, resizeMode: 'contain' }}
              source={image_m}  />
            <Text style={{ fontSize: 20, color: "black" }}> { route.params?.mon > 300 ?"포유류. 주로 나무에서 생활하며, 다른 동물과 다르게 인간처럼 손의 사용 빈도가 높다.나무막대기 같은 간단한 도구를 손에 들고 가지고 다니거나 하기도 한다. " : "-"}</Text>
          </View>
          <View style={styles.box}>
            <Image
              style={{ height: 100, width: 100, resizeMode: 'contain' }}
              source={image_p}  />
            <Text style={{ fontSize: 20, color: "black" }}> { route.params?.pen > 400 ?"펭귄과의 동물. 키는 40~120cm이고, 등은 검은색, 배는 흰색이다. 다리는 몸의 뒤쪽에 있으며 날개는 짧고 지느러미 모양으로 변화하여 작아서 날지 못한다. " : "-"}</Text>
          </View>
        </View>
        <View style={{ backgroundColor: '#CFC810', flexDirection: 'row' }}>
          <View style={styles.box}>
            <Image
              style={{ height: 100, width: 100, resizeMode: 'contain' }}
              source={image_t} />
            <Text style={{ fontSize: 20, color: "black" }}> { route.params?.tigNum > 0 ?"아시아에 서식하는 식육목 고양잇과의 포유류. 현존하는 모든 고양잇과 동물들 중 가장 큰 동물로 무게는 100~360kg 정도 나간다." : "-"}</Text>
          </View>
          <View style={styles.box}>
            <Image
              style={{ height: 100, width: 100, resizeMode: 'contain' }}
              source={image_l} />
            <Text style={{ fontSize: 20, color: "black" }}> { route.params?.lionNum > 0 ? "아프리카와 인도에 서식하는 식육목 고양잇과 포유류. 간지나는 비주얼과 강인한 사냥 능력으로 오랫동안 '백수의 왕'으로 불린다." : "-"}</Text>
          </View>
        </View>
        <View style={{ backgroundColor: '#CFC810', flexDirection: 'row' }}>
          <View style={styles.box}>
            <Image
              style={{ height: 100, width: 100, resizeMode: 'contain' }}
              source={image_d} />
            <Text style={{ fontSize: 20, color: "black" }}> { route.params?.dragonNum > 0 ? "용(龍)은 동아시아 설화에 나오는 상상의 동물이다.날씨를 다스리거나 하는 능력을 가지고 있으며, 평상시에는 구름 위를 다니는 모양.  " : "-"}</Text>
          </View>
          <View style={styles.box}>
            <Image
              style={{ height: 100, width: 100, resizeMode: 'contain' }}
              source={image_c} />
            <Text style={{ fontSize: 20, color: "black" }}> { route.params?.chameleonNum > 0 ? "카멜레온과의 생물.체형이 세로로 넓직하며, 돌출된 두 안구는 360º로 따로 돌아가고, 작은 구멍이 뚫린 눈꺼풀이 항시 덮고 있다. 몸의 색이 변한다. " : "-"}</Text>
          </View>
        </View>
        <View style={{ backgroundColor: '#CFC810', flexDirection: 'row' }}>
          <View style={styles.box}>
            <Image
              style={{ height: 100, width: 100, resizeMode: 'contain' }}
              source={image_s} />
            <Text style={{ fontSize: 20, color: "black" }}> { route.params?.sunfishNum > 0 ? "복어목 개복치과에 속하는 초대형 어류. 쟁반형의 거대하고 넓은 몸에 몸의 끝쪽 위 아래로 뾰족한 지느러미가 돋아나 있는 재미있는 물고기이다. " : "-"}</Text>
          </View>
          <View style={styles.box}>
            <Image
              style={{ height: 100, width: 100, resizeMode: 'contain' }}
              source={require('./assets/lock.png')} />
            <Text style={{ fontSize: 20, color: "black" }}> - </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}


let GameCount = 0; //게임 점수 = 돈
let BuyZoo = 0; //동물블럭 나오는지 여부 판단

let BuyEleNum = 0;
let BuyGirNum = 0;
let BuyMonNum = 0;
let BuyPenNum = 0;
let BuyTigerNum = 0;
let BuyLionNum = 0;
let BuyDragonNum = 0;
let BuyChameleonNum = 0;
let BuySunfishNum = 0;

const MiniGameBox = (props) => {

  const x = useSharedValue(0);
  const y = useSharedValue(0);
  const color = useSharedValue("blue");
  const scale = useSharedValue(1);
  const [active, setActive] = useState(false);
  const [changeGir, setChangeGir] = useState(require('./assets/giraffe.png'));


  useEffect(() => {
    activate(props.active);
  }, [props.active]);

  useEffect(() => {
    switch (props.action) {
      case "jump":
        //jump();

        setTimeout(() => {
          props.cleanupAction();
        }, 200);
        break;
    }

  }, [props.action]);




  const Move = () => {
    x.value = Random.getRandomBytes(1) % 400-200;  //-200 ~ 200


    let prob = Random.getRandomBytes(1) % 100;

    if(BuyZoo == 1)
    {
      if (x.value <= 0) {
        setChangeGir(require('./assets/elephant.png'));
        x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
      }
      else if (x.value > 0) {
        setChangeGir(require('./assets/elephant.png'));
        x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
      }
    }

    else if(BuyZoo == 2){
      if (x.value <= 0) {
        if(prob < 50)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
      else if (x.value > 0) {
        
        if(prob < 50)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
    }

    else if(BuyZoo == 3){
      if (x.value <= 0) {
        if(prob < 30)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 30 && prob < 50)
        {
          setChangeGir(require('./assets/monkey.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
      else if (x.value > 0) {
        
        if(prob < 30)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 30 && prob < 50)
        {
          setChangeGir(require('./assets/monkey.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
    }

    else if(BuyZoo == 4){
      if (x.value <= 0) {
        if(prob < 20)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 20 && prob < 40)
        {
          setChangeGir(require('./assets/monkey.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 40 && prob < 50)
        {
          setChangeGir(require('./assets/penguin.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
      else if (x.value > 0) {
        
        if(prob < 20)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 20 && prob < 40)
        {
          setChangeGir(require('./assets/monkey.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 40 && prob < 50)
        {
          setChangeGir(require('./assets/penguin.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
    }
    
    else if(BuyZoo == 5){
      if (x.value <= 0) {
        if(prob < 15)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 15 && prob < 30)
        {
          setChangeGir(require('./assets/monkey.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 30 && prob < 45)
        {
          setChangeGir(require('./assets/penguin.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 45 && prob < 50)
        {
          setChangeGir(require('./assets/tiger.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
      else if (x.value > 0) {
        
        if(prob < 15)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 15 && prob < 30)
        {
          setChangeGir(require('./assets/monkey.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 30 && prob < 45)
        {
          setChangeGir(require('./assets/penguin.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 45 && prob < 50)
        {
          setChangeGir(require('./assets/tiger.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
    }
    
    else if(BuyZoo == 6){
      if (x.value <= 0) {
        if(prob < 10)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 10 && prob < 20)
        {
          setChangeGir(require('./assets/monkey.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 20 && prob < 30)
        {
          setChangeGir(require('./assets/penguin.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 30 && prob < 40)
        {
          setChangeGir(require('./assets/tiger.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 40 && prob < 50)
        {
          setChangeGir(require('./assets/lion.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
      else if (x.value > 0) {       
        if(prob < 10)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 10 && prob < 20)
        {
          setChangeGir(require('./assets/monkey.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 20 && prob < 30)
        {
          setChangeGir(require('./assets/penguin.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 30 && prob < 40)
        {
          setChangeGir(require('./assets/tiger.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 40 && prob < 50)
        {
          setChangeGir(require('./assets/lion.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
    }

    else if(BuyZoo == 7){
      if (x.value <= 0) {
        if(prob < 10)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 10 && prob < 20)
        {
          setChangeGir(require('./assets/monkey.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 20 && prob < 30)
        {
          setChangeGir(require('./assets/penguin.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 30 && prob < 40)
        {
          setChangeGir(require('./assets/tiger.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 40 && prob < 50)
        {
          setChangeGir(require('./assets/lion.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 50 && prob < 55)
        {
          setChangeGir(require('./assets/dragon.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
      else if (x.value > 0) {       
        if(prob < 10)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 10 && prob < 20)
        {
          setChangeGir(require('./assets/monkey.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 20 && prob < 30)
        {
          setChangeGir(require('./assets/penguin.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 30 && prob < 40)
        {
          setChangeGir(require('./assets/tiger.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 40 && prob < 50)
        {
          setChangeGir(require('./assets/lion.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 50 && prob < 55)
        {
          setChangeGir(require('./assets/dragon.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
    }

    else if(BuyZoo == 8){
      if (x.value <= 0) {
        if(prob < 10)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 10 && prob < 20)
        {
          setChangeGir(require('./assets/monkey.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 20 && prob < 30)
        {
          setChangeGir(require('./assets/penguin.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 30 && prob < 40)
        {
          setChangeGir(require('./assets/tiger.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 40 && prob < 50)
        {
          setChangeGir(require('./assets/lion.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 50 && prob < 55)
        {
          setChangeGir(require('./assets/dragon.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 55 && prob < 60)
        {
          setChangeGir(require('./assets/chameleon.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
      else if (x.value > 0) {       
        if(prob < 10)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 10 && prob < 20)
        {
          setChangeGir(require('./assets/monkey.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 20 && prob < 30)
        {
          setChangeGir(require('./assets/penguin.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 30 && prob < 40)
        {
          setChangeGir(require('./assets/tiger.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 40 && prob < 50)
        {
          setChangeGir(require('./assets/lion.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 50 && prob < 55)
        {
          setChangeGir(require('./assets/dragon.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 55 && prob < 60)
        {
          setChangeGir(require('./assets/chameleon.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
    }

    else if(BuyZoo == 9){
      if (x.value <= 0) {
        if(prob < 10)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 10 && prob < 20)
        {
          setChangeGir(require('./assets/monkey.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 20 && prob < 30)
        {
          setChangeGir(require('./assets/penguin.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 30 && prob < 40)
        {
          setChangeGir(require('./assets/tiger.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 40 && prob < 50)
        {
          setChangeGir(require('./assets/lion.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 50 && prob < 55)
        {
          setChangeGir(require('./assets/dragon.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 55 && prob < 60)
        {
          setChangeGir(require('./assets/chameleon.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 60 && prob < 63)
        {
          setChangeGir(require('./assets/sunfish.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(+200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
      else if (x.value > 0) {       
        if(prob < 10)
        {
          setChangeGir(require('./assets/giraffe.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 10 && prob < 20)
        {
          setChangeGir(require('./assets/monkey.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 20 && prob < 30)
        {
          setChangeGir(require('./assets/penguin.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 30 && prob < 40)
        {
          setChangeGir(require('./assets/tiger.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 40 && prob < 50)
        {
          setChangeGir(require('./assets/lion.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 50 && prob < 55)
        {
          setChangeGir(require('./assets/dragon.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 55 && prob < 60)
        {
          setChangeGir(require('./assets/chameleon.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else if(prob >= 60 && prob < 63)
        {
          setChangeGir(require('./assets/sunfish.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
        else
        {
          setChangeGir(require('./assets/elephant.png'));
          x.value = repeat(withTiming(-200, { duration: 2000, ease: Easing.linear }), -1, true);
        }
      }
    }
  }

  const jump = () => {
    x.value = withTiming(x.value + 10, { duration: 200, ease: Easing.linear });
    y.value = repeat(withTiming(y.value - 80, { duration: 100 }), 2, true);
  }

  const blink = () => { }

  const setColor = (c) => color.value = c;

  const activate = (newActive = true) => {
    setColor(newActive ? "orange" : "blue");
    setActive(newActive);
    Move();
  };

  const onTap = () => {

    setChangeGir(null);

    props.activate(!active);
    if (changeGir == require('./assets/giraffe.png')) {
      GameCount += 1*(1+((BuyGirNum-1) / 10));
    }
    else if(changeGir == require('./assets/monkey.png')) {
      GameCount += 1.4*(1+((BuyMonNum-1) / 10));
    }
    
    else if(changeGir == require('./assets/penguin.png')) {
      GameCount += 2*(1+((BuyPenNum-1) / 10));
    }
    
    else if(changeGir == require('./assets/tiger.png')) {
      GameCount += 2.5*(1+((BuyTigerNum-1) / 10));
    }
    
    else if(changeGir == require('./assets/lion.png')) {
      GameCount += 3*(1+((BuyLionNum-1) / 10));
    }
    
    else if(changeGir == require('./assets/dragon.png')) {
      GameCount += 3.3*(1+((BuyDragonNum-1) / 10));
    }
    
    else if(changeGir == require('./assets/chameleon.png')) {
      GameCount += 3.7*(1+((BuyChameleonNum-1) / 10));
    }
    
    else if(changeGir == require('./assets/sunfish.png')) {
      GameCount += 4*(1+((BuySunfishNum-1) / 10));
    }

    else {
      GameCount += 0.5*(1+((BuyEleNum -1) / 10));
    }

    console.log(GameCount);
  }

  const animatedStyle = useAnimatedStyle(() => {
    return {
      borderRadius: 5,


      left: props.left,
      top: props.top,
      transform: [
        { translateX: x.value },
        { translateY: y.value },
        { scale: scale.value }
      ]
    }
  });
  return (

    <Animated.View style={[animatedStyle]} >
      <TouchableWithoutFeedback
        onPress={onTap} >
        <Image style={{ height: 50, width: 50, resizeMode: 'contain' }}
          source={changeGir} />
      </TouchableWithoutFeedback>
    </Animated.View>

  );
}

const Boxes = (props) => {
  const [boxes, setBoxes] = useState([{
    name: 'box 1',
    left: 0, top: 450, width: 50, height: 50, active: false
  }, {
    name: 'box 2',
    left: 0, top: 500, width: 50, height: 50, active: false
  }
  ]); // react hook

  const intersect = (x, y, w, h, x1, y1, w1, h1) =>
    y + h >= y1 && y1 + h1 >= y && x + w >= x1 && x1 + w1 >= x;

  const cleanupAction = () => { }

  const add = () => {
    let myBoxes = [...boxes];
    myBoxes.push({
      name: `box ${Math.floor(Math.random() * 100000)}`,
      left: Math.random() * 300, top: Math.random() * 600,
      width: 100, height: 100, active: false
    });
    setBoxes(myBoxes);
  }

  const remove = () => {
    let myBoxes = boxes.filter((box) => box.active === false);
    setBoxes(myBoxes);
  }

  const jump = () => {
    console.log("Boxes jump called");
  }
  const blink = () => { }

  const activate = (name, newActive) => {
    let myBoxes = [...boxes]; // spread operator ... 전개 연산자
    myBoxes.forEach((box) => {
      if (box.name == name)
        box.active = newActive;
    });
    setBoxes(myBoxes);
  }

  let boxesRender = [];
  for (let i = 0; i < boxes.length; i++) {
    let box = boxes[i];
    if (boxes[i])
      boxesRender.push(<MiniGameBox name={box.name} key={box.name}
        left={box.left} top={box.top}
        width={box.width} height={box.height}
        active={box.active} action={box.action}
        cleanupAction={cleanupAction}
        activate={(flag) => activate(box.name, flag)}
      />
      );
  }


  return (
    <View >
      { boxesRender}
    </View>);
}

class minigame extends React.Component {
  state = {
    setStartBool: true,
    setEndBool: false,
    timeBool: false,
    timenum: 10,
    GameMoney: 0
  }

  //설명창 끄기
  setStartModal = () => {
    this.setState({ setStartBool: false });
    this.setState({ timeBool: true });
  }

  // 결과창 띄우기
  setEndModal = () => {
    this.setState({ setEndBool: true })
  }

  //메인으로 가는거
  Main = () => {
    GameCount = GameCount.toFixed(1);
    this.props.navigation.navigate('Main', { MiniGameMoney: GameCount });
    console.log(GameCount);
  }


  render() {
    const { setStartBool, timeBool, timenum, setEndBool, GameMoney } = this.state;
    return (
      <ImageBackground source={require('./assets/Minigame.jpg')} style={{ resizeMode: 'cover', justifyContent: 'center', flex: 1, }}>
        <View style={{ flex: 1, alignItems: 'center' }}>
          <View style={{ width: 100, height: 50, backgroundColor: '#FFBF55', top: 10, alignItems: 'center', justifyContent: 'center', flexDirection: 'row' }}>
            <Image style={{ height: 30, width: 30, resizeMode: 'contain' }}
              source={require('./assets/clock.png')} />
            <CountDown until={timenum} digitStyle={{ backgroundColor: '#FFBF55' }} size={20} timeToShow={['S']} timeLabels={{ s: '' }} running={timeBool} onFinish={this.setEndModal} />
          </View>

          <Boxes></Boxes>

          <Modal
            animationType="fade"
            transparent={true}
            visible={setStartBool}
            onRequestClose={() => {
            }}>
            <View style={styles.centeredView} >
              <View style={styles.MinigameView}>

                <View style={{ flex: 1, justifyContent: 'center' }}>
                  <Text style={{ textAlign: 'center', fontSize: 40 }}>미니게임</Text>
                </View>
                <View style={{ flex: 2, justifyContent: 'center' }}>
                  <Text style={{ textAlign: 'center', fontSize: 20 }}>1. 동물이 지나갑니다.</Text>
                  <Text style={{ textAlign: 'center', fontSize: 20 }}>2. 시간안에 클릭해서 동물을 밀렵하세요.</Text>
                  <Text style={{ textAlign: 'center', fontSize: 20 }}>3. 잡은 동물은 돈으로 환산됩니다.</Text>
                  <Text style={{ textAlign: 'center', fontSize: 20 }}>4. 시작버튼을 누르면 시작합니다.</Text>
                </View>

                <View style={{ flex: 1, justifyContent: 'center' }}>
                  <Button contentStyle={{ height: 40, width: 120, }} labelStyle={{ color: "white", fontSize: 20 }}
                    color='#754F44' mode="contained" onPress={this.setStartModal}> 시작 </Button>
                </View>
              </View>
            </View>
          </Modal>

          <Modal
            animationType="fade"
            transparent={true}
            visible={setEndBool}
            onRequestClose={() => {
            }}>
            <View style={styles.centeredView}>
              <View style={styles.MinigameView}>

                <View style={{ flex: 1, justifyContent: 'center' }}>
                  <Text style={{ textAlign: 'center', fontSize: 40 }}>결과창</Text>
                </View>
                <View style={{ flex: 2, justifyContent: 'center' }}>
                  <Text style={{ textAlign: 'center', fontSize: 30 }}> {GameCount.toFixed(1) * 100}를 얻었습니다. </Text>
                </View>

                <View style={{ flex: 1, justifyContent: 'center' }}>
                  <Button contentStyle={{ height: 40, width: 120, }} labelStyle={{ color: "white", fontSize: 20 }}
                    color='#754F44' mode="contained" onPress={this.Main}> 확인 </Button>
                </View>
              </View>
            </View>
          </Modal>

        </View>

      </ImageBackground>

    );
  }
}

export default function App() {

  return (
    <NavigationContainer>
      <Stack.Navigator headerMode="none">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Main" component={MainScreen} />
        <Stack.Screen name="Quest" component={QuestScreen} />
        <Stack.Screen name="AnimalBook" component={AnimalBookScreen} />


        <Stack.Screen name="Animal" component={AnimalScreen} />
        <Stack.Screen name="Store" component={StoreScreen} />
        <Stack.Screen name="ZooKeeper" component={ZooKeeperScreen} />
        <Stack.Screen name="Roulette" component={RouletteScreen} />
        <Stack.Screen name="MiniGame" component={minigame} />

      </Stack.Navigator>
    </NavigationContainer>

  );
}







const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  AnimalButton: {
    alignItems: 'center',
    justifyContent: 'center',
    color: 'red',
  },
  MainScreenStyle: {


    alignItems: 'center',
    justifyContent: 'center',
  },

  MainScreenAni: {


    alignItems: 'center',
    justifyContent: 'center',
  },

  AppBarStyle: {
    flex: 1,

  },

  ButtenStyle: {
    flex: 0.4,
    backgroundColor: 'gray',
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'center',
  },

  TopStyle:
  {
    flex: 0.4,
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'center',
  },

  AnimalSceenStyle:
  {
    flex: 2,
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-around'
  },

  AnimalSceenBackColor: {
    backgroundColor: 'brown'
  },

  StoreSceenBackColor: {
    backgroundColor: 'yellow',
  },

  ZookeeperSceenBackColor: {
    backgroundColor: 'skyblue',
  },


  headDelete: {
    elevation: 0,
    shadowOpacity: 0,
    borderBottomWidth: 0,
  },

  circle: {
    width: 150,
    height: 150,
    backgroundColor: "#c00000",
    borderRadius: 100
  },

  centeredView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: "rgba(0,0,0,0.5)"
  },

  modalView: {
    margin: 20,
    backgroundColor: '#FBFFB9',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 25,

    //창크기
    width: 300,
    height: 500
  },

  InView: {
    margin: 100,
    backgroundColor: '#FBFFB9',
    borderRadius: 20,

    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 25,

    //창크기
    width: 300,
    height: 400
  },

  MinigameView: {
    margin: 100,
    backgroundColor: '#FBFFB9',
    borderRadius: 20,

    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 25,

    //창크기
    width: 350,
    height: 300
  },

  EndMoneyView: {
    margin: 100,
    backgroundColor: '#FBFFB9',
    borderRadius: 20,

    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 25,

    //창크기
    width: 270,
    height: 320
  },

  RoulletView: {
    margin: 20,
    backgroundColor: '#FBFFB9',
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 25,

    //창크기
    width: 300,
    height: 400
  },

  ProbView: { //확률 창
    margin: 20,
    backgroundColor: '#FBFFB9',
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 25,

    //창크기
    width: 300,
    height: 400
  },






  openButton: {
    backgroundColor: '#F194FF',
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    fontSize: 40,
    marginBottom: 50,
  },

  buttona: {
    width: 90,
    height: 113,
    left: 0,
    top: 527,
  },

  box: {
    width: 200,
    height: 307,
    backgroundColor: '#B46E06',
    alignItems: 'center',
    margin: 5,
  },

  box2: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'center',
    flex: 3,
  },


  box123: {
    position: 'absolute',
    width: 80,
    height: 80,
    backgroundColor: "blue",
  },
  commandText: {
    flex: 1,
    fontWeight: 'bold',
    textAlign: 'center',
    textAlignVertical: 'center',
    color: 'white'
  },



  quest: {
    flexDirection: 'row',
  },

  questbutton: {
    alignItems: 'flex-end',
  },

  SettingScreen: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-around',
  },


});
